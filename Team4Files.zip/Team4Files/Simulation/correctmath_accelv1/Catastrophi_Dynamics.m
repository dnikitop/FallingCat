function dxdt = Catastrophi_Dynamics(primal)
% Dynamics file for Problem Brac:1
%   References: 
%       1. Beginner's Guide to DIDO
%       2. The DIDO Tutorial
%       3. Page 88 of Chapter 2 of Ross (see documents folder)
%       4. Page 12 of Ross, "A Primer on Pontryagin's Principle in Optimal
%           Control, Second Edition, Collegiate Publishers, San Francisco,
%           2015.
%====================================

%-----------------------------------------
% Call preamble and load primal variables:
%-----------------------------------------

[th1, th2, cly1, cly2, cly3, th1dot, th2dot, ... % states
     acc1, acc2, t, ...                                                 % controls and time
     x_0, t0, ...                                                         % endpoints at t0
     x_f, tf, ...                                                          % endpoints at tf
     m1, m2, eta, I1, I2, s1, s2, ...                             % constants
     DU] ...                                                               % scaling factors
                    = Catastrophi_Preamble(primal); 
            
% th1 = th1*DU.thz ; 
% th2 = th2*DU.thz ; 
% cly1 = cly1*DU.clyz ; 
% cly2 = cly2*DU.clyz ; 
% cly3 = cly3*DU.clyz ;
% th1dot = th1dot*DU.thdotz ; 
% th2dot = th2dot*DU.thdotz ; 
% 
% acc1 = acc1*DU.tauz;
% acc2 = acc2*DU.tauz;

% t = t*DU.tz ;

% Ignore MATLAB's suggestion to replace the unused variables by a ~ (tilde).
% Keeping the unused variables makes the code easier to read.

%=====================
% Equations of Motion:
%=====================

N = length(th1) ;
clydot = zeros(3,N) ;
thddot = zeros(2,N) ;

    for i = 1:N

%         x = [th1(:,i); th2(:,i); cly1(:,i); cly2(:,i); cly3(:,i)] ;
        x = [[th1(:,i); th2(:,i)]*DU.thz;
               [cly1(:,i); cly2(:,i); cly3(:,i)]*DU.clyz] ;
        theta_dot = [th1dot(:,i); th2dot(:,i)]*DU.thdotz ;%

        B = B_calc(x) ;

        thdot(:,i) = theta_dot ;
        clydot(:,i) = B*theta_dot ;
        thddot(:,i) = [acc1(:,i); acc2(:,i)]*DU.accz ;
    end
    
% dxdt = [thdot; clydot; thddot] ;    
dxdt = [thdot/(DU.thz/DU.tz); clydot/(DU.clyz/DU.tz); thddot/(DU.thdotz/DU.tz)] ;
%dxdt = [thdot/DU.thdotz; clydot/(DU.clyz/DU.tz); thddot/DU.accz] ;

%dxdt = [1/thdotz 1/thdotz 1/clyz 1/clyz 1/clyz 1/tauz 1/tauz]'.*[xdot; thddot];
%=====================
% eof
%====

%% FUNCTION Calculation of B
    function B = B_calc(x)

    %    global I1 I2 s1 s2 eta
        %Inertia matrices for the bodies in body frame

        theta1 = x(1) ;
        theta2 = x(2) ;

        skew_s1 = to_skewSymm(s1);
        skew_s2 = to_skewSymm(s2);

        A = R2(theta1)*R1(theta2)*R3(-pi/2)*R2(pi) ;

        cly123 = x(3:5) ;%*
        cly0 = 1/(1 + cly123'*cly123) ;%*

        alpha1 = cly123(1);%*
        alpha2 = cly123(2);%*
        alpha3 = cly123(3);%*

        Q = to_skewSymm(cly123);
        A1 = (eye(3)+Q)*inv(eye(3)-Q) ;%Cayley to rotation matrix conversion 
        
        A2 = A1*A ;%*

        %Generalized matrix
        J1 = I1 + eta*(skew_s1'*skew_s1);%*
        J2 = I2 + eta*(skew_s2'*skew_s2);%*
        J12 = eta*(skew_s1*A*skew_s2);%*
        J = [J1 J12; J12' J2];%*

    % U: Jacobian of w1 = U*clydot
   % oh, now I know how U is calculated!! 
        U = [((2*alpha1 - 2*alpha2*alpha3)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...   
                (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha1 - 2*alpha2*alpha3)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
                ((2*alpha1 - 2*alpha2*alpha3)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha2 + 2*alpha1*alpha3)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1);
                ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha3 + 2*alpha1*alpha2)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
                ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
                (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1);
                (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
                ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha1 + 2*alpha2*alpha3)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
                (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)];

        Il = J1 + A*J2*A' + A*J12' + J12*A';%*
        
        b = [cos(theta2), 0; % 2-1 (th2,th1)
                0, 1;
                sin(theta2), 0];
            
        b1 = b(:,1) ; 
        b2 = b(:,2) ; 

    %     B1 = [eye(2) zeros(2,3); 
    %              zeros(3,2) Il*U];%*
    %     B2 = [1 0; 
    %              0 1; 
    %              -(A*J2+J12)*b1, -(A*J2 + J12)*b2];%*
        B = -inv(Il*U)*(A*J2+J12)*[b1 b2] ;% eqn 16
             
%        B = inv(B1)*B2;%*

    end

%%
    function skewSymmMat = to_skewSymm(vec)
        skewSymmMat = [0 -vec(3) vec(2); 
                                   vec(3) 0 -vec(1); 
                                  -vec(2) vec(1) 0];%*
    end

    % FUNCTION ROTATION MATRICES
    function R = R1(phi)     
        R = [1 0 0; 
               0 cos(phi) -sin(phi);
               0 sin(phi) cos(phi)];
    end
    function R = R2(phi)     
        R = [cos(phi) 0 sin(phi);  
               0 1 0;                               
             -sin(phi) 0 cos(phi)];
    end
    function R = R3(phi)     
        R = [cos(phi) -sin(phi) 0;
               sin(phi) cos(phi) 0;
               0 0 1];        
    end

end