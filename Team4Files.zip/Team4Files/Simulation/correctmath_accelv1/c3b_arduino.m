clear; format compact; 

load 'LOAD_Propagate.mat';

tD_ = tD' ;
xD_ = xD' ;
uD_ = tauD' ;

xn = size(xD_,1) ;
un = size(uD_,1) ;
R = eye(un) ;
Q = eye(xn) ;
Qf = 10*Q ; 
x0_ = 1.3*x0 ; 

tD_ = linspace(tf,T,20) ;
N_ = length(tD_)-1 ;
tD_ = [tD' tD_(2:end)] ;
xD_ = [xD_ (xf*ones(1,N_))] ;
uD_ = [uD_ zeros(un,N_)] ;

%% 100 Hz
f = 100 ;%[Hz] frequency to send to Arduino
dt = 1/f ;%[s] time change between steps

t_d = [0:dt:T] ;% desired time split
x_d = interp1(tD_', xD_', t_d)' ;
A = [t_d' x_d(1,:)'*180/pi x_d(1,:)'*180/pi];

u_d = interp1(tD_', uD_', t_d)' ;

fileID = fopen('arduino_cmd_100Hz.txt','w');
fprintf(fileID,'%10s %15s %15s \n','t (s)','theta1 (deg)','theta2 (deg)');
fprintf(fileID,'%10.4f %15.8f %15.8f \n',A');
fclose(fileID);

type arduino_cmd_100Hz.txt

%% 100 Hz
f = 300 ;%[Hz] frequency to send to Arduino
dt = 1/f ;%[s] time change between steps

t_d = [0:dt:T] ;% desired time split
x_d = interp1(tD_', xD_', t_d)' ;
A = [t_d' x_d(1,:)'*180/pi x_d(1,:)'*180/pi];

u_d = interp1(tD_', uD_', t_d)' ;

fileID = fopen('arduino_cmd_300Hz.txt','w');
fprintf(fileID,'%10s %15s %15s \n','t (s)','theta1 (deg)','theta2 (deg)');
fprintf(fileID,'%10.4f %15.8f %15.8f \n',A');
fclose(fileID);

type arduino_cmd_300Hz.txt

