% clc;
% clear all;
% close all;
load 'LOAD_Propagate.mat';

global tD xD tauD tf

animateCat(xD);
function animateCat(x)
    global  tD xD tauD tf
    x = x';
    % z is axis of cat body
    %Inertial frame attached to center of mass of body 1 at r1(0,0,0)
    link = [1 1] ;
    leg = 0.4 ;
    figure ;
    pause(5);
%     videoFReader = vision.VideoFileReader('viplanedeparture.mp4');
%     videoFWriter = vision.VideoFileWriter('myFile.avi','FrameRate',...
%     videoFReader.info.VideoFrameRate);
    for i = 1:size(x,2)
        cly123 = x(3:5, i); 
        th      = x(1:2, i);  
        Q = to_skewSymm(cly123);
        
        % Defining rotation matrices
        R = (eye(3)+Q)*inv(eye(3)-Q);
        % Basic rotation matrices
        R1 = [1 0 0; 0 cos(th(1)) -sin(th(1)); 0 sin(th(1)) cos(th(1))]; %x-rot
        R2 = [cos(th(2)) 0 sin(th(2)); 0 1 0; -sin(th(2)) 0 cos(th(2))]; % y-rot
        R3 = [cos(th(1)) -sin(th(1)) 0; sin(th(1)) cos(th(1)) 0; 0 0 1]; %z-rot
        % From dynamics equations
        R3_ = [cos(th(1)) sin(th(1))*sin(th(2)) sin(th(1))*cos(th(2));
                0 cos(th(2)) -sin(th(2));
                -sin(th(1)) cos(th(1))*sin(th(2)) cos(th(1))*cos(th(2))];
    
        l1 = link(1)/2;

        r1 = [0 0 0];
        T1 = [eye(3) [0 0 l1]'; [0 0 0 1]];
        A1 = [R [0 0 0]'; [0 0 0 1]];
        Tleg1 = [eye(3) [-leg 0 -l1]'; [0 0 0 1]];

        r2 = A1*T1*[0 0 0 1]'; % End of link 1, start of link 2

        T0 = [eye(3) [0 0 -l1]'; [0 0 0 1]];
        r0 = A1*T0*[0 0 0 1]'; %Start of link 1
        
        A3 = [R2 [0 0 0]'; [0 0 0 1]];
        A3_ = [R3_ [0 0 0]'; [0 0 0 1]];
        A33 = [R3 [0 0 0]'; [0 0 0 1]];
        
        T3 = [eye(3) [0 0 link(2)]'; [0 0 0 1]];
        T33 = [eye(3) [0 0 link(2)/2]'; [0 0 0 1]];
%         r3 = A1*T1*A3*A33*T3*[0 0 0 1]'; %End of link 2
        r3 = A1*T1*A3_*T3*[0 0 0 1]'; %End of link 2
        
        r4 = A1*T1*A3*A33*T33*[0 0 0 1]';
        Tleg2 = [eye(3) [-leg 0 link(2)]'; [0 0 0 1]];
        leg1 = A1*Tleg1*[0 0 0 1]';
%         leg2 = A1*T1*A3*A33*Tleg2*[0 0 0 1]';
        leg2 = A1*T1*A3_*Tleg2*[0 0 0 1]';
        
        clf;

%        subplot(3,4,[3:4,7:8,11:12])
        subplot(3,4,[2:3,6:7,10:11])        
        R = 0.2;
        N = 30;
        [X,Y,Z]=cylinder2P(R,N,r0(1:3)',r2(1:3)'); % Link 1
        surf(X,Y,Z);
        hold on;
        [X2,Y2,Z2]=cylinder2P(R,N,r2(1:3)',r3(1:3)'); % Link2
        surf(X2,Y2,Z2);
        R = 0.1;
        [X3,Y3,Z3]=cylinder2P(R,N,r0(1:3)',leg1(1:3)'); % Leg1
        surf(X3,Y3,Z3);
        [X4,Y4,Z4]=cylinder2P(R,N,r3(1:3)',leg2(1:3)'); %Leg2
        surf(X4,Y4,Z4);
        
        axis([-2 3 -1.4 2 -1.4 2]);
        title('Cat reorientation')
        
        
        subplot(341); plot(tD,tauD(:,1)); xlim([0,tf]); hold on;
        plot(tD(i),tauD(i,1),'or','markersize',10);
        ylabel('Torque (N-m)','fontsize',16)
        subplot(344); plot(tD,tauD(:,2)); xlim([0,tf]); hold on;
        plot(tD(i),tauD(i,2),'or','markersize',10);
        ylabel('Torque (N-m)','fontsize',16)

        subplot(345); plot(tD,xD(:,6)*30/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(i,6)*30/pi,'or','markersize',10);
        ylabel('Rate (RPM)','fontsize',16)
        subplot(348); plot(tD,xD(:,7)*30/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(i,7)*30/pi,'or','markersize',10);
        ylabel('Rate (RPM)','fontsize',16)

        subplot(349); plot(tD,xD(:,1)*180/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(i,1)*180/pi,'or','markersize',10); 
        xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)
        subplot(3,4,12); plot(tD,xD(:,2)*180/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(i,2)*180/pi,'or','markersize',10); 
        xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)
        
        
        
        
        xlabel('x') % x-axis label
        ylabel('y') % y-axis label
        zlabel('z') % y-axis label
        Mov(i) = getframe;
        pause(0.01);
    end
    save('movie','Mov');
     load('movie.mat')
%     v = VideoWriter('movie.mat','Motion JPEG 2000')
%     open(v);
% writeVideo(v,rand(300));

% close(v);
%     release(videoFReader);
%     release(videoFWriter);
%     load('movie.mat')
%     movie(Mov,2) % To play it two times
end
function skewSymmMat = to_skewSymm(vec)
    skewSymmMat = [0 -vec(3) vec(2); vec(3) 0 -vec(1); -vec(2) vec(1) 0];
end