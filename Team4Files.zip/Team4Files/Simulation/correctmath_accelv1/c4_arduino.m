format compact; clear; clc; 

load LOAD_Propagate.mat

%% 150 Hz
f = 50 ;%[Hz] frequency to send to Arduino
dt = 1/f ;%[s] time change between steps

xD_ = xD ;
tD_ = tD ;
tD = [0:dt:T] ;% desired time split
xD = interp1(tD_', xD_', tD)' ;
%A = [tD' xD(1,:)'*180/pi xD(1,:)'*180/pi];

%%

p1 = xD(1,:)*180/pi + 90;
p2 = xD(2,:)*180/pi + 90;

pm1 = round(p1,0) ;
pm2 = round(p2,0) ;

p1 = p1 - min(p1);
p2 = p2 - min(p2);

figure, plot(tD,p1,'linewidth',3), hold on;
plot(tD,p2,'linewidth',3)
title('Total Angle Movement','fontsize',18)
xlabel('time [s]','fontsize',16), ylabel('Total Angle Movement [deg]','fontsize',16)
leg = legend('\theta_1','\theta_2') ;
leg.FontSize = 16 ;

save('LOAD_Arduino_CMD.mat','pm1','pm2')
% %num2str(p1(1),uint8)
% s1 = ['[']
% s2 = ['[']
% 
% N = length(p1)
% for i = 1:N
% 
%     if i < N
%         s1 = [s1 num2str(p1(i),'%4.0f, \n')];
%         s2 = [s2 num2str(p2(i),'%4.0f, \n')];
%     else
%         s1 = [s1 num2str(p1(i),'%4.0f] \n')]
%         s2 = [s2 num2str(p2(i),'%4.0f] \n')]        
%     end
% end

