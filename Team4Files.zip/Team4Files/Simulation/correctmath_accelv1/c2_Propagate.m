format compact; clear; clc;
global x0 xf N dt I1 I2 T s1 s2 eta u_max Alpha n t ACC

load LOAD_DIDO.mat

% %
n = 10;
% N = length(th1);

% for t_ = linspace(0,T,N)
% 
%     theta_dot = [theta_dot u_alpha(t_, Alpha)];
% 
% end
                  
%% ODE45 PROPAGATION

ACC = [acc1; acc2] ;

[tP xP] = ode45(@ODE_Dynamics,[0 tf], x0) ;

%
freq = 300 ;%[Hz]
tD = 0:1/freq:tf ; 

N = length(tD) ;
accD = spline(t,ACC,tD) ;
xD = spline(tP',xP',tD) ;
tauD = zeros(3,N-1) ;

skew_s1 = to_skewSymm(s1) ;
skew_s2 = to_skewSymm(s2) ;

for i = 1:N
    t_ = tD(i) ;
    th = xD(1:2,i) ;
    cly = xD(3:5,i) ; 
    thdot = xD(6:7,i) ;

    theta1 = th(1) ;
    theta2 = th(2) ;
    
    A = R2(theta1)*R1(theta2)*R3(-pi/2)*R2(pi) ; 

    cly0 = 1/(1 + cly'*cly) ;%*

    alpha1 = cly(1) ;
    alpha2 = cly(2) ;
    alpha3 = cly(3) ;

    Q = to_skewSymm(cly);
    A1 = (eye(3)+Q)*inv(eye(3)-Q) ;%Cayley to rotation matrix conversion 
    A2 = A1*A ;%*

    J1 = I1 + eta*(skew_s1'*skew_s1) ;
    J2 = I2 + eta*(skew_s2'*skew_s2) ;
    J12 = eta*(skew_s1*A*skew_s2) ;
    J = [J1 J12; J12' J2] ;
    Il = J1 + A*J2*A' + A*J12' + J12*A' ;

    % U: Jacobian of w1 = U*clydot
   % oh, now I know how U is calculated!! 
    U = [((2*alpha1 - 2*alpha2*alpha3)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...   
            (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha1 - 2*alpha2*alpha3)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            ((2*alpha1 - 2*alpha2*alpha3)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha2 + 2*alpha1*alpha3)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1);
            ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha3 + 2*alpha1*alpha2)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1);
            (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha1 + 2*alpha2*alpha3)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)];

    b = [cos(theta2), 0;
            0, 1;
            sin(theta2), 0];
    b1 = b(:,1) ; 
    b2 = b(:,2) ; 

    % BEGIN NEW CODE
    w = b*thdot ;
    w1 = (Il*A1)\(-(A2*J2 + A1*J12))*w ;
    w2 = (Il*A2)\(A1*J1 + A2*J12')*A*w ;  
    skew_w1 = to_skewSymm(w1);
    skew_w2 = to_skewSymm(w2);

%     wdot = [cos(theta2)*sin(theta2)*th2dot^2 - cos(theta1)*cos(theta2)*(cos(theta1)*sin(theta2)*th1dot^2 + cos(theta1)*sin(theta2)*th2dot^2 - cos(theta1)*cos(theta2)*th2ddot + sin(theta1)*sin(theta2)*th1ddot + 2*cos(theta2)*sin(theta1)*th1dot*th2dot) + cos(theta2)*sin(theta1)*(cos(theta1)*sin(theta2)*th1ddot - sin(theta1)*sin(theta2)*th2dot^2 - sin(theta1)*sin(theta2)*th1dot^2 + cos(theta2)*sin(theta1)*th2ddot + 2*cos(theta1)*cos(theta2)*th1dot*th2dot) + sin(theta2)*sin(theta2)*th2ddot + conj(th2dot)*sin(theta2)*cos(theta2)*th2dot + conj(th1dot)*cos(theta1)*cos(theta2)*(cos(theta1)*sin(theta2)*th1dot + cos(theta2)*sin(theta1)*th2dot) - conj(th1dot)*cos(theta2)*sin(theta1)*(cos(theta1)*cos(theta2)*th2dot - sin(theta1)*sin(theta2)*th1dot) - conj(th2dot)*cos(theta1)*sin(theta2)*(cos(theta1)*cos(theta2)*th2dot - sin(theta1)*sin(theta2)*th1dot) - conj(th2dot)*sin(theta1)*sin(theta2)*(cos(theta1)*sin(theta2)*th1dot + cos(theta2)*sin(theta1)*th2dot);  
%                 sin(theta1)*(cos(theta1)*cos(theta2)*th1dot^2 + cos(theta1)*cos(theta2)*th2dot^2 + cos(theta2)*sin(theta1)*th1ddot + cos(theta1)*sin(theta2)*th2ddot - 2*sin(theta1)*sin(theta2)*th1dot*th2dot) - cos(theta1)*(cos(theta2)*sin(theta1)*th1dot^2 + cos(theta2)*sin(theta1)*th2dot^2 - cos(theta1)*cos(theta2)*th1ddot + sin(theta1)*sin(theta2)*th2ddot + 2*cos(theta1)*sin(theta2)*th1dot*th2dot) + conj(th1dot)*cos(theta1)*(cos(theta2)*sin(theta1)*th1dot + cos(theta1)*sin(theta2)*th2dot) - conj(th1dot)*sin(theta1)*(cos(theta1)*cos(theta2)*th1dot - sin(theta1)*sin(theta2)*th2dot);
%                 sin(theta2)*cos(theta2)*th2dot^2 - cos(theta1)*sin(theta2)*(cos(theta1)*cos(theta2)*th1dot^2 + cos(theta1)*cos(theta2)*th2dot^2 + cos(theta2)*sin(theta1)*th1ddot + cos(theta1)*sin(theta2)*th2ddot - 2*sin(theta1)*sin(theta2)*th1dot*th2dot) - sin(theta1)*sin(theta2)*(cos(theta2)*sin(theta1)*th1dot^2 + cos(theta2)*sin(theta1)*th2dot^2 - cos(theta1)*cos(theta2)*th1ddot + sin(theta1)*sin(theta2)*th2ddot + 2*cos(theta1)*sin(theta2)*th1dot*th2dot) - cos(theta2)*cos(theta2)*th2ddot + conj(th2dot)*cos(theta2)*sin(theta2)*th2dot - conj(th2dot)*cos(theta1)*cos(theta2)*(cos(theta2)*sin(theta1)*th1dot + cos(theta1)*sin(theta2)*th2dot) + conj(th1dot)*cos(theta1)*sin(theta2)*(cos(theta1)*cos(theta2)*th1dot - sin(theta1)*sin(theta2)*th2dot) + conj(th2dot)*cos(theta2)*sin(theta1)*(cos(theta1)*cos(theta2)*th1dot - sin(theta1)*sin(theta2)*th2dot) + conj(th1dot)*sin(theta1)*sin(theta2)*(cos(theta2)*sin(theta1)*th1dot + cos(theta1)*sin(theta2)*th2dot)];

    if i >1 
        w1dot = (w1 - w1_old) / (t_ - t_old) ;
        w2dot = (w2 - w2_old) / (t_ - t_old) ;
        wdot = [w1dot; w2dot] ;

        TERM1 = skew_w1*J1*w1 + eta*skew_s1*A*skew_w2*skew_s2*w2 ;
        TERM2 = skew_w2*J2*w2 + eta*skew_s2*A'*skew_w1*skew_s1*w1 ;
%         TERM1 = cross(w1,J1*w1) + eta*skew_s1*A*skew_w2*skew_s2*w2 ;
%         TERM2 = cross(w2,J2*w2) + eta*skew_s2*A'*skew_w1*skew_s1*w1 ;
        TERM = [TERM1; TERM2] ;

        AI = [-A; eye(3)] ;
        tauD(1:3,i-1) = pinv(AI)*(J*wdot + TERM) ;
    end
        
    t_old = t_ ;        
    w1_old = w1 ;
    w2_old = w2 ;    

end

% figure, plot(tD(1:end-1),tauD(1,:)), hold on;
%            plot(tD,accD(1,:)/100), legend('torque (N-m)','acceleration (rad/s^2)')

      %       
%
% [t,x,u,tau] = tau_propagate(tD,xD,tauD) ;
% clear tD xD tauD
% tD = t' ;
% xD = [x u] ;
% tauD = tau' ;

% ODE45 PLOTS                

% Plot Torque Velocity Angle
figure, hold on;
subplot(321); plot(tD,accD(1,:)); xlim([0,tf]); 
ylabel('Torque (N-m)','fontsize',16)
subplot(322); plot(tD,accD(2,:)); xlim([0,tf]); 
ylabel('Torque (N-m)','fontsize',16)
subplot(323); plot(tD,xD(6,:)*30/pi); xlim([0,tf]); 
ylabel('Rate (RPM)','fontsize',16)
subplot(324); plot(tD,xD(7,:)*30/pi); xlim([0,tf]); 
ylabel('Rate (RPM)','fontsize',16)
subplot(325); plot(tD,xD(1,:)*180/pi); xlim([0,tf]); 
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)
subplot(326); plot(tD,xD(2,:)*180/pi); xlim([0,tf]); 
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)

% Plot Caley Parameters
figure, hold on
subplot(221); plot(tD,xD(3,:)); xlim([0,tf]); 
ylabel('c1','fontsize',16)
subplot(222); plot(tD,xD(4,:)); xlim([0,tf]); 
ylabel('c2','fontsize',16)
subplot(223); plot(tD,xD(5,:)); xlim([0,tf]); 
xlabel('Time [s]','fontsize',16); ylabel('c3','fontsize',16)

%%

save('LOAD_Propagate.mat')

c2b_animate_joints_witharrows
%}

%% FUNCTION create Tau
function [t,x,u,tau] = tau_propagate(tD,xD,uD)

    global I1 I2 s1 s2 eta
    
    skew_s1 = to_skewSymm(s1);
    skew_s2 = to_skewSymm(s2);

    N = 1000 ;
    t = linspace(0,tD(end),N) ;
    u = zeros(2,N) ;

    x = (spline(tD',xD',t))' ; 
    u = (spline(tD',uD',t))' ; 
    
    for i = 1:N
        t_ = t(i) ; 
        th = x(i,1:2)' ;
        cly = x(i,3:5)' ;
        thdot = u(i,:)' ;
        
        % FROM B_CALC
        theta1 = th(1) ;
        theta2 = th(2) ;

        A = R2(theta1)*R1(theta2)*R3(-pi/2)*R2(pi) ; 
  
        cly0 = 1/(1 + cly'*cly) ;%*

        alpha1 = cly(1) ;
        alpha2 = cly(2) ;
        alpha3 = cly(3) ;

        Q = to_skewSymm(cly);
        A1 = (eye(3)+Q)*inv(eye(3)-Q) ;%Cayley to rotation matrix conversion 
        A2 = A1*A ;%*

        J1 = I1 + eta*(skew_s1'*skew_s1) ;
        J2 = I2 + eta*(skew_s2'*skew_s2) ;
        J12 = eta*(skew_s1*A*skew_s2) ;

        J = [J1 J12; J12' J2] ;

    % U: Jacobian of w1 = U*clydot
   % oh, now I know how U is calculated!! 
    U = [((2*alpha1 - 2*alpha2*alpha3)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...   
            (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha1 - 2*alpha2*alpha3)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            ((2*alpha1 - 2*alpha2*alpha3)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha2 + 2*alpha1*alpha3)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1);
            ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha3 + 2*alpha1*alpha2)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha2 - 2*alpha1*alpha3)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1);
            (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2*alpha1 + 2*alpha2*alpha3)*(2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1), ...  
            (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + ((2*alpha3 - 2*alpha1*alpha2)*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)];

        Il = J1 + A*J2*A' + A*J12' + J12*A' ;

        b = [cos(theta2), 0;
                0, 1;
                sin(theta2), 0];

        b1 = b(:,1) ; 
        b2 = b(:,2) ; 
 
%         % BEGIN NEW CODE
%         w = b*thdot ;
%         w1 = (Il*A1)\(-(A2*J2 + A1*J12))*w ;
%         w2 = (Il*A2)\(A1*J1 + A2*J12')*A*w ;  
%         skew_w1 = to_skewSymm(w1);
%         skew_w2 = to_skewSymm(w2);
%         
%         wdot = [cos(theta2)*sin(theta2)*th2dot^2 - cos(theta1)*cos(theta2)*(cos(theta1)*sin(theta2)*th1dot^2 + cos(theta1)*sin(theta2)*th2dot^2 - cos(theta1)*cos(theta2)*th2ddot + sin(theta1)*sin(theta2)*th1ddot + 2*cos(theta2)*sin(theta1)*th1dot*th2dot) + cos(theta2)*sin(theta1)*(cos(theta1)*sin(theta2)*th1ddot - sin(theta1)*sin(theta2)*th2dot^2 - sin(theta1)*sin(theta2)*th1dot^2 + cos(theta2)*sin(theta1)*th2ddot + 2*cos(theta1)*cos(theta2)*th1dot*th2dot) + sin(theta2)*sin(theta2)*th2ddot + conj(th2dot)*sin(theta2)*cos(theta2)*th2dot + conj(th1dot)*cos(theta1)*cos(theta2)*(cos(theta1)*sin(theta2)*th1dot + cos(theta2)*sin(theta1)*th2dot) - conj(th1dot)*cos(theta2)*sin(theta1)*(cos(theta1)*cos(theta2)*th2dot - sin(theta1)*sin(theta2)*th1dot) - conj(th2dot)*cos(theta1)*sin(theta2)*(cos(theta1)*cos(theta2)*th2dot - sin(theta1)*sin(theta2)*th1dot) - conj(th2dot)*sin(theta1)*sin(theta2)*(cos(theta1)*sin(theta2)*th1dot + cos(theta2)*sin(theta1)*th2dot);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               sin(theta1)*(cos(theta1)*cos(theta2)*th1dot^2 + cos(theta1)*cos(theta2)*th2dot^2 + cos(theta2)*sin(theta1)*th1ddot + cos(theta1)*sin(theta2)*th2ddot - 2*sin(theta1)*sin(theta2)*th1dot*th2dot) - cos(theta1)*(cos(theta2)*sin(theta1)*th1dot^2 + cos(theta2)*sin(theta1)*th2dot^2 - cos(theta1)*cos(theta2)*th1ddot + sin(theta1)*sin(theta2)*th2ddot + 2*cos(theta1)*sin(theta2)*th1dot*th2dot) + conj(th1dot)*cos(theta1)*(cos(theta2)*sin(theta1)*th1dot + cos(theta1)*sin(theta2)*th2dot) - conj(th1dot)*sin(theta1)*(cos(theta1)*cos(theta2)*th1dot - sin(theta1)*sin(theta2)*th2dot);
%         sin(theta2)*cos(theta2)*th2dot^2 - cos(theta1)*sin(theta2)*(cos(theta1)*cos(theta2)*th1dot^2 + cos(theta1)*cos(theta2)*th2dot^2 + cos(theta2)*sin(theta1)*th1ddot + cos(theta1)*sin(theta2)*th2ddot - 2*sin(theta1)*sin(theta2)*th1dot*th2dot) - sin(theta1)*sin(theta2)*(cos(theta2)*sin(theta1)*th1dot^2 + cos(theta2)*sin(theta1)*th2dot^2 - cos(theta1)*cos(theta2)*th1ddot + sin(theta1)*sin(theta2)*th2ddot + 2*cos(theta1)*sin(theta2)*th1dot*th2dot) - cos(theta2)*cos(theta2)*th2ddot + conj(th2dot)*cos(theta2)*sin(theta2)*th2dot - conj(th2dot)*cos(theta1)*cos(theta2)*(cos(theta2)*sin(theta1)*th1dot + cos(theta1)*sin(theta2)*th2dot) + conj(th1dot)*cos(theta1)*sin(theta2)*(cos(theta1)*cos(theta2)*th1dot - sin(theta1)*sin(theta2)*th2dot) + conj(th2dot)*cos(theta2)*sin(theta1)*(cos(theta1)*cos(theta2)*th1dot - sin(theta1)*sin(theta2)*th2dot) + conj(th1dot)*sin(theta1)*sin(theta2)*(cos(theta2)*sin(theta1)*th1dot + cos(theta1)*sin(theta2)*th2dot)];
  
%         if i >1 
%             w1dot = (w1 - w1_old) / (t_ - t_old) ;
%             w2dot = (w2 - w2_old) / (t_ - t_old) ;
%             wdot = [w1dot; w2dot] ;
%             
% %             TERM1 = skew_w1*J1*w1 + eta*skew_s1*A*skew_w2*skew_s2*w2 ;
% %             TERM2 = skew_w2*J2*w2 + eta*skew_s2*A'*skew_w1*skew_s1*w1 ;
%             TERM1 = cross(w1,J1*w1) + eta*skew_s1*A*skew_w2*skew_s2*w2 ;
%             TERM2 = cross(w2,J2*w2) + eta*skew_s2*A'*skew_w1*skew_s1*w1 ;
%             TERM = [TERM1; TERM2] ;
%             
%             AI = [-A; eye(3)] ;
%             tau(1:3,i-1) = pinv(AI)*(J*wdot + TERM) ;
%         end
        
        t_old = t_ ;        
        w1_old = w1 ;
        w2_old = w2 ;
        
    end

end

%% FUNCTION DYNAMICS FOR ODE45
function xdot = ODE_Dynamics(t_,x)
    global t ACC I1 I2 %Alpha
    
    acc = zeros(2,1);
    acc(1) = spline(t,ACC(1,:),t_) ;
    acc(2) = spline(t,ACC(2,:),t_) ; 

    thddot = acc;
    
    B = B_calc(x(1:5)) ;

    theta_dot = x(6:7) ;

    xdot = [theta_dot; B*theta_dot; thddot] ;
    
end

function B = B_calc(x)

    global I1 I2 s1 s2 eta

    theta1 = x(1) ;
    theta2 = x(2) ;

    skew_s1 = to_skewSymm(s1) ;
    skew_s2 = to_skewSymm(s2) ;
    
    A = R2(theta1)*R1(theta2)*R3(-pi/2)*R2(pi) ; 
            
    cly123 = x(3:5) ;
    cly0 = 1/(1 + cly123'*cly123) ;

    alpha1 = cly123(1) ;
    alpha2 = cly123(2) ;
    alpha3 = cly123(3) ;

    Q = to_skewSymm(cly123);
    A1 = (eye(3)+Q)*inv(eye(3)-Q) ;%Cayley to rotation matrix conversion 
    
    A2 = A1*A ;

    J1 = I1 + eta*(skew_s1'*skew_s1) ;
    J2 = I2 + eta*(skew_s2'*skew_s2) ;
    J12 = eta*(skew_s1*A*skew_s2) ;
    J = [J1 J12; J12' J2] ;

    U = [((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1), (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        ((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1);...
        ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1), (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1);...
        (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1)];

    Il = J1 + A*J2*A' + A*J12' + J12*A';%*

    b = [cos(theta2), 0; % 2-1 (th2,th1)
            0, 1;
            sin(theta2), 0];
    b1 = b(:,1) ; 
    b2 = b(:,2) ; 
  
    B = -inv(Il*U)*(A*J2+J12)*[b1 b2] ;% eqn 16
        
end

%% FUNCTION SKEW SYMMETRIC MATRIX
function skewSymmMat = to_skewSymm(vec)
    skewSymmMat = [0 -vec(3) vec(2); 
                               vec(3) 0 -vec(1); 
                              -vec(2) vec(1) 0] ;
end
%% FUNCTION ROTATION MATRICES
function R = R1(phi)     
    R = [1 0 0; 
           0 cos(phi) -sin(phi);
           0 sin(phi) cos(phi)];
end
function R = R2(phi)     
    R = [cos(phi) 0 sin(phi);  
           0 1 0;                               
         -sin(phi) 0 cos(phi)];
end
function R = R3(phi)     
    R = [cos(phi) -sin(phi) 0;
           sin(phi) cos(phi) 0;
           0 0 1];        
end