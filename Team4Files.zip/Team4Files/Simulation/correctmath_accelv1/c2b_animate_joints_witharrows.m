% clc;
% clear all;
% close all;

load 'LOAD_Propagate.mat';

global tD xD accD tf

animateCat(xD);


% load x.mat
% animateCat(x);
function animateCat(x)
    global  tD xD accD tf
%    x = x';
    % z is axis of cat body
    %Origin is at center of link 1
    %Theta 1 is rotation about y-axis
    %Theta 2 is rotation about x-axis
    %z-axis points outwards from the hinge
    %Inertial frame attached to center of mass of body 1 at r1(0,0,0)
    link = [1 1] ;
    leg = 0.4 ;
%    figure ;
    figure('units','normalized','outerposition',[0 0 1 1])
%     pause(2);
%     videoFReader = vision.VideoFileReader('viplanedeparture.mp4');
%     videoFWriter = vision.VideoFileWriter('myFile.avi','FrameRate',...
%     videoFReader.info.VideoFrameRate);
n = 1 ;% how refined is iteration
    for j = 1:size(x,2)/n
        i = j*n;
        cly123 = x(3:5, i);
        th      = x(1:2, i);  
        Q = to_skewSymm(cly123);

        % Defining rotation matrices
        R = (eye(3)+Q)*inv(eye(3)-Q);
       
        %From paper
        R3_ = [cos(th(1)) 0 sin(th(1));
            0 1 0;
            -sin(th(1)) 0 cos(th(1))]*...
            [0 1 0;
             cos(th(2)) 0 sin(th(2)); 
             sin(th(2)) 0 -cos(th(2))]; % A from paper
    
        l1 = link(1)/2;

        T1 = [eye(3) [0 0 l1]'; [0 0 0 1]]; %hinge
        A1 = [R [0 0 0]'; [0 0 0 1]];
        Tleg1 = [eye(3) [-leg 0 -l1]'; [0 0 0 1]];
        r1 = A1*[0 0 0 1]';
        r2 = A1*T1*[0 0 0 1]'; % End of link 1, start of link 2

        T0 = [eye(3) [0 0 -l1]'; [0 0 0 1]];
        r0 = A1*T0*[0 0 0 1]'; %Start of link 1
        
        A3_ = [R3_ [0 0 0]'; [0 0 0 1]];
        
        T3 = [eye(3) [0 0 -link(2)]'; [0 0 0 1]]; % end of link 2
        r3 = A1*T1*A3_*T3*[0 0 0 1]'; %End of link 2
        r2_3 = A1*T1*A3_*[0 0 -link(2)/2 1]'; % mid of link 2
        Tleg2 = [eye(3) [0 -leg -link(2)]'; [0 0 0 1]];
        leg1 = A1*Tleg1*[0 0 0 1]';
        leg2 = A1*T1*A3_*Tleg2*[0 0 0 1]';
        Arrowy1 = A1*[eye(3) [0 2*l1 0]'; [0 0 0 1]]*[0 0 0 1]';
        Arrowx1 = A1*[eye(3) [2*l1 0 0]'; [0 0 0 1]]*[0 0 0 1]';
        Arrowz1 = A1*[eye(3) [0 0 2*l1]'; [0 0 0 1]]*[0 0 0 1]';
        
        Arrowy2 = A1*T1*A3_*[eye(3) [0 2*l1 0]'; [0 0 0 1]]*[0 0 0 1]';
        Arrowx2 = A1*T1*A3_*[eye(3) [2*l1 0 0]'; [0 0 0 1]]*[0 0 0 1]';
        Arrowz2 = A1*T1*A3_*[eye(3) [0 0 2*l1]'; [0 0 0 1]]*[0 0 0 1]';
        clf;

        subplot(3,4,[2:3,6:7,10:11])        
        R = 0.2;
        N = 30;
        [X,Y,Z]=cylinder2P(R,N,r0(1:3)',r2(1:3)'); % Link 1
        surf(X,Y,Z);
        hold on;
        [X2,Y2,Z2]=cylinder2P(R,N,r2(1:3)',r3(1:3)'); % Link2
        surf(X2,Y2,Z2);
        R = 0.1;
        [X3,Y3,Z3]=cylinder2P(R,N,r0(1:3)',leg1(1:3)'); % Leg1
        surf(X3,Y3,Z3);
        [X4,Y4,Z4]=cylinder2P(R,N,r3(1:3)',leg2(1:3)'); %Leg2
        surf(X4,Y4,Z4);
        mArrow3(r1(1:3)', Arrowy1(1:3)', 'facealpha', 0.5, 'color', 'blue', 'stemWidth', 0.02);
        mArrow3(r1(1:3)', Arrowx1(1:3)', 'facealpha', 0.5, 'color', 'red', 'stemWidth', 0.02);
        mArrow3(r1(1:3)', Arrowz1(1:3)', 'facealpha', 0.5, 'color', 'green', 'stemWidth', 0.02);
        
        mArrow3(r2_3(1:3)', Arrowy2(1:3)', 'facealpha', 0.5, 'color', 'blue', 'stemWidth', 0.02);
        mArrow3(r2_3(1:3)', Arrowx2(1:3)', 'facealpha', 0.5, 'color', 'red', 'stemWidth', 0.02);
        mArrow3(r2_3(1:3)', Arrowz2(1:3)', 'facealpha', 0.5, 'color', 'green', 'stemWidth', 0.02);
        
        h(1) = plot(NaN,NaN,'-r');
        h(2) = plot(NaN,NaN,'-b');
        h(3) = plot(NaN,NaN,'-g');
        h(4) = plot(NaN,NaN,'-r');
        h(5) = plot(NaN,NaN,'-b');
        h(6) = plot(NaN,NaN,'-g');
      %  legend(h, 'x-axis (Theta2)','y-axis (Theta1)', 'z-axis', 'x-axis (Theta2)','y-axis (Theta1)', 'z-axis');
        %axis([-3 4 -3 4 -3 4]);
        axis([-3 4 -3 4 -3 4]*.5);
        title('Cat reorientation','fontsize',30)
        
        xlabel('x') % x-axis label
        ylabel('y') % y-axis label
        zlabel('z') % y-axis label
        
%         subplot(341); plot(tD,tauD(:,1)); xlim([0,tf]); hold on;
%         plot(tD(i),tauD(i,1),'or','markersize',10);
%         ylabel('Torque (N-m)','fontsize',16)
%         subplot(344); plot(tD,tauD(:,2)); xlim([0,tf]); hold on;
%         plot(tD(i),tauD(i,2),'or','markersize',10);
%         ylabel('Torque (N-m)','fontsize',16)

        subplot(341); plot(tD,accD(1,:)); xlim([0,tf]); hold on;
        plot(tD(i),accD(1,i),'or','markersize',10);
        title('Pitch','fontsize',20)
        ylabel('Acceleration (rad/s^2)','fontsize',16)
        subplot(344); plot(tD,accD(2,:)); xlim([0,tf]); hold on;
        plot(tD(i),accD(2,i),'or','markersize',10);
        title('Yaw','fontsize',20)
        ylabel('Acceleration (rad/s^2)','fontsize',16)
        
        subplot(345); plot(tD,xD(6,:)*30/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(6,i)*30/pi,'or','markersize',10);
        ylabel('Rate (RPM)','fontsize',16)
        subplot(348); plot(tD,xD(7,:)*30/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(7,i)*30/pi,'or','markersize',10);
        ylabel('Rate (RPM)','fontsize',16)

        subplot(349); plot(tD,xD(1,:)*180/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(1,i)*180/pi,'or','markersize',10); 
        xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)
        subplot(3,4,12); plot(tD,xD(2,:)*180/pi); xlim([0,tf]); hold on;
        plot(tD(i), xD(2,i)*180/pi,'or','markersize',10); 
        xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)
        
        Mov(i) = getframe;
%         pause(0.0001);
    end
    save('movie','Mov');
     load('movie.mat')
%     v = VideoWriter('movie.mat','Motion JPEG 2000')
%     open(v);
% writeVideo(v,rand(300));

% close(v);
%     release(videoFReader);
%     release(videoFWriter);
%     load('movie.mat')
%     movie(Mov,2) % To play it two times
end
function skewSymmMat = to_skewSymm(vec)
    skewSymmMat = [0 -vec(3) vec(2); vec(3) 0 -vec(1); -vec(2) vec(1) 0];
end