function [th1, th2, cly1, cly2, cly3, th1dot, th2dot, ... % states
     acc1, acc2, t, ...                                                 % controls and time
     x_0, t0, ...                                                         % endpoints at t0
     x_f, tf, ...                                                          % endpoints at tf
     m1, m2, eta, I1, I2, s1, s2, ...                             % constants
     DU] ...                   % scaling factors
                    = Catastrophi_Preamble(primal)
                
% % global bounds
% %===================================        

th1 = primal.states(1,:);              %   States
th2 = primal.states(2,:);
cly1 = primal.states(3,:);
cly2 = primal.states(4,:);
cly3 = primal.states(5,:);
th1dot = primal.states(6,:);       %   Controls
th2dot = primal.states(7,:);

acc1 = primal.controls(1,:);       %   Controls
acc2 = primal.controls(2,:);

t = primal.time ;                          %   time

x_0 = primal.initial.states ;         % initial states
t0 =   primal.initial.time;              %   initial time

x_f = primal.final.states ;           % final states
tf =   primal.final.time;                 %   final time

m1 = primal.constants.CON.m1 ;        %   constants (data)
m2 = primal.constants.CON.m2 ;
eta = primal.constants.CON.eta ;
I1 = primal.constants.CON.I1 ;
I2 = primal.constants.CON.I2 ;
s1 = primal.constants.CON.s1 ;
s2 = primal.constants.CON.s2 ;

DU = primal.constants.DU ;

% eof