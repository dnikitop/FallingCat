clear; format compact; 

load 'LOAD_Propagate.mat';

global Q R t_d x_d u_d I1 I2 s1 s2 eta ts_flip S_COL_flip

tD_ = tD' ;
xD_ = xD(:,1:5)' ;
uD_ = xD(:,6:7)' ;

xn = size(xD_,1) ;
un = size(uD_,1) ;
R = eye(un) ;
Q = eye(xn) ;
Qf = 10*Q ; 
x0_ = 1.3*x0(1:5) ; 

tD_ = linspace(tf,T,20) ;
N_ = length(tD_)-1 ;
tD_ = [tD' tD_(2:end)] ;
xD_ = [xD_ (xf(1:5)*ones(1,N_))] ;
uD_ = [uD_ zeros(un,N_)] ;

%% RICATTI 
N = 100 ;
t_d = linspace(0,T,N) ;
x_d = interp1(tD_', xD_', t_d)' ;
u_d = interp1(tD_', uD_', t_d)' ;

sT = Qf ;
ST_col = reshape(sT,[xn^2,1]) ;

size(ST_col)

[ts,S_COL] = ode45(@Ricatti, linspace(T,0,N)', ST_col); 


S_COL_flip = flip(S_COL) ;
ts_flip = flip(ts) ;

[t,x] = ode45(@Dyn, t_d, x0_);


%% 
% Plot Torque Velocity Angle
tD_ = tD_';
xD_ = xD_';
uD_ = uD_';

figure, hold on;
subplot(221); plot(tD_,uD_(:,1)); xlim([0,T]);
ylabel('Velocity (RPM)','fontsize',16)

subplot(222); plot(tD_,uD_(:,2)); xlim([0,T]); 
ylabel('Velocity (RPM)','fontsize',16)

subplot(223); plot(tD_,xD_(:,1)*180/pi); xlim([0,T]); 
hold on; plot(t,x(:,1)*180/pi);
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)

subplot(224); plot(tD_,xD_(:,2)*180/pi); xlim([0,T]); 
hold on; plot(t,x(:,2)*180/pi);
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)

% Plot Caley Parameters
figure, hold on
subplot(221); plot(tD_,xD_(:,3)); xlim([0,T]); 
hold on; plot(t,x(:,3));
ylabel('c1','fontsize',16)

subplot(222); plot(tD_,xD_(:,4)); xlim([0,T]);
hold on; plot(t,x(:,4));
ylabel('c2','fontsize',16)

subplot(223); plot(tD_,xD_(:,5)); xlim([0,T]); 
hold on; plot(t,x(:,5));
xlabel('Time [s]','fontsize',16); ylabel('c3','fontsize',16)


%[tN xN] = ode45(@ODE_Dynamics,[0 T], x0) ;
%% RICATTI DYNAMICS
function S_dot_col =  Ricatti(t,S_col)%,x_nom,x_d, u_nom,u_d,t0)
    global Q R x_d t_d u_d

    xn = size(x_d,1) ;
    un = size(u_d,1) ;

    xd = interp1(t_d',x_d',t)' ;
    u = interp1(t_d',u_d',t)' ;

    A = A_xPartial(xd,u) ; %Finite Diff A
    B = B_uPartial(xd,u) ; %Finite Diff B
  
    S = reshape(S_col(1:xn^2),[xn,xn]);
    
    S_dot = -( Q - S*B*R^(-1)*B'*S + S*A + A'*S ) ;
    S_dot_col = S_dot(:);
end

%% A(t) - Finite Diff partial wrt states
function partial = A_xPartial(x,u)
    nx = size(x,1);
    nf = size(x,1);
    partial = zeros(nf,nx);
    eps = 1e-4;

    for i = 1:nx
        x_ = x ;
        x_(i) = x_(i)+eps ;
        f=R_Dynamics(x,u) ;
        f_eps=R_Dynamics(x_,u) ;
        partial(:,i)=(f_eps-f)/eps ;
    end
end

%% B(t) - Finite Diff partial wrt states
function partial = B_uPartial(x,u)
    nu = size(u,1);
    nf = size(x,1);
    partial = zeros(nf,nu);
    eps = 1e-4;

    for i = 1:nu
        u_ = u ;
        u_(i) = u_(i)+eps ;
        f=R_Dynamics(x,u) ;
        f_eps=R_Dynamics(x,u_) ;
        partial(:,i)=(f_eps-f)/eps ;
    end
end

%% Dynamics for RICATTI
function xdot = R_Dynamics(x,u)
    global I1 I2 
    
    B = B_calc(x(1:5)) ;
    
    theta_dot = u ;
     
    xdot = [B*theta_dot];%*
end

%% Dynamics for ODE Propagation
function dxdt_col = Dyn(t,x,u)
    global R t_d x_d u_d ts_flip S_COL_flip
    xn = size(x_d,1) ;
    un = size(u_d,1) ;
    
    u = interp1(t_d',u_d',t)' ;

    B = B_uPartial(x,u) ; % Finite Diff B

    ts = ts_flip ;
    S_COL = S_COL_flip ;
    
    S = reshape(interp1(ts,S_COL(:,1:xn^2),t),[xn,xn]); 
    
    xd = interp1(t_d',x_d',t)' ;

    xbar = x-xd ;
    
    ud = interp1(t_d',u_d',t)' ;
    ustar = ud-R^(-1)*B'*S*xbar ; 
    
    dxdt = R_Dynamics(x,ustar) ;
            
    dxdt_col = reshape(dxdt,[xn,1]); 
end

%% FUNCTION Calculation of B
function B = B_calc(x)

    global I1 I2 s1 s2 eta
    %Inertia matrices for the bodies in body frame

    theta1 = x(1) ;
    theta2 = x(2) ;

    skew_s1 = to_skewSymm(s1);
    skew_s2 = to_skewSymm(s2);

    %Rotation matrices for the bodies in inertial frame
% Check A (eqn 14, page 388)
%       A = [cos(theta1) 0 sin(theta1); 0 1 0; -sin(theta1) 0 cos(theta1)]*[0 1 0;cos(theta2) 0 sin(theta2); sin(theta2) 0 -cos(theta2)];
    A = [cos(theta1) sin(theta1)*sin(theta2) sin(theta1)*cos(theta2);
            0 cos(theta2) -sin(theta2);
          -sin(theta1) cos(theta1)*sin(theta2) cos(theta1)*cos(theta2)];
%    A = [cos(theta1) 0 sin(theta1); 0 1 0; -sin(theta1) 0 cos(theta1)]*[1 0 0;0 cos(theta2) -sin(theta2); 0 sin(theta2) cos(theta2)]
    cly123 = x(3:5) ;%*
    cly0 = 1/(1 + cly123'*cly123) ;%*

%     alpha0 = 1/(1+Q(1,2)^2+Q(1,3)^2+Q(2,3)^2);
    alpha1 = cly123(1);%*
    alpha2 = cly123(2);%*
    alpha3 = cly123(3);%*
%     alpha = [alpha0 alpha1 alpha2 alpha3];

% Changed calculation of A1 per pg 386
    A1_ = cly0*...
            [1 + alpha1^2 - alpha2^2 - alpha3^2,...
             2*(alpha1*alpha2 - alpha3),...
             2*(alpha1*alpha3 + alpha2);
             2*(alpha1*alpha2 + alpha3),...
             1 - alpha1^2 + alpha2^2 - alpha3^2,...
             2*(alpha2*alpha3 - alpha1);
             2*(alpha1*alpha3 - alpha2),...
             2*(alpha2*alpha3 + alpha1),...
             1 - alpha1^2 - alpha2^2 + alpha3^2] ;%*
%
    Q = to_skewSymm(cly123);
%     Q = (eye(3)-A1)*inv(eye(3)+A1);
    A1 = (eye(3)+Q)*inv(eye(3)-Q) ;%Cayley to rotation matrix conversion 
    %A1 = inv(eye(3)+Q)*(eye(3)-Q) ;%Cayley to rotation matrix conversion        %%%%%%%%%%%%%%%%%%%%%%%%

    A_diff = norm(A1-A1_) ;% check difference between A1 calculations (VERY DIFFERENT!!)
    A2 = A1*A ;%*

    %Generalized matrix
    J1 = I1 + eta*(skew_s1'*skew_s1);%*
    J2 = I2 + eta*(skew_s2'*skew_s2);%*
    J12 = eta*(skew_s1*A*skew_s2);%*

    J = [J1 J12; J12' J2];%*

% NOT SURE HOW U IS CALCULATED
    U = [((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1), (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        ((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1);...
        ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1), (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1);...
        (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1)];

    %    
    Il = J1 + A*J2*A' + A*J12' + J12*A';%*
    b2 = [0;1;0];%*
    b1 = [cos(theta2); 0; sin(theta2)];%*
    B1 = [1 0 zeros(1,3); 
             0 1 zeros(1,3); 
             zeros(3,2) Il*U];%*
    B2 = [1 0; 
             0 1; 
             -(A*J2+J12)*b1 -(A*J2 + J12)*b2];%*
    B = inv(B1)*B2;%*

end

% %% FUNCTION - Create rotation matrix from Caley Parameters
% function R = Rot_cly(t_)
%     global tD xD
% 
%     c123 = zeros(3,1);
%     c123(1) = spline(tD,xD(:,3),t_);
%     c123(2) = spline(tD,xD(:,4),t_);
%     c123(3) = spline(tD,xD(:,5),t_);
%     
%     Q = to_skewSymm(cly123) ;
%         % Defining rotation matrices
%     R = (eye(3)+Q)*inv(eye(3)-Q) ;
% 
% end

%% FUNCTION - Skew Symmetric Matrix 
function skewSymmMat = to_skewSymm(vec)
    skewSymmMat = [0 -vec(3) vec(2); 
                               vec(3) 0 -vec(1); 
                              -vec(2) vec(1) 0];%*
end
