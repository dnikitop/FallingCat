function endpointFunction = Catastrophi_Events(primal)
% Events file for Catastrophi
%====================================

%-----------------------------------------
% Call preamble and load primal variables:
%-----------------------------------------

[th1, th2, cly1, cly2, cly3, th1dot, th2dot, ... % states
     acc1, acc2, t, ...                                                 % controls and time
     x_0, t0, ...                                                         % endpoints at t0
     x_f, tf, ...                                                          % endpoints at tf
     m1, m2, eta, I1, I2, s1, s2, ...                             % constants
     DU] ...                                                               % scaling factors
                    = Catastrophi_Preamble(primal); 
        
%            global bounds
            
% Ignore MATLAB's suggestion to replace the unused variables by a ~ (tilde).
% Keeping the unused variables makes the code easier to read.

%% preallocate the endpointFunction evaluation for good MATLAB computing

% if size(bounds.events,1)==13
%     endpointFunction = zeros(13,1);      % t0 is specified in the problem file
%     endpointFunction(10) = cly1_f;
%     endpointFunction(11) = cly2_f;
%     endpointFunction(12) = thdot1_f;
%     endpointFunction(13) = thdot2_f;
% else
%     endpointFunction = zeros(14,1);      % t0 is specified in the problem file
%     endpointFunction(10) = cly1_f;
%     endpointFunction(11) = cly2_f;
%     endpointFunction(12) = cly3_f;
%     endpointFunction(13) = thdot1_f;
%     endpointFunction(14) = thdot2_f;
% end

endpointFunction = zeros(14,1);      % t0 is specified in the problem file
% endpointFunction = zeros(13,1);      % t0 is specified in the problem file

%=========================
% endpointFunction(1) = th1_0;
% endpointFunction(2) = th2_0;
% endpointFunction(3) = cly1_0;
% endpointFunction(4) = cly2_0;
% endpointFunction(5) = cly3_0;
% endpointFunction(6) = thdot1_0;
% endpointFunction(7) = thdot2_0;

endpointFunction = [x_0; x_f];

%------------------------
% endpointFunction(8) = th1_f;
% endpointFunction(9) = th2_f;
% endpointFunction(10) = cly1_f;
% endpointFunction(11) = cly2_f;
% endpointFunction(12) = cly3_f;
% endpointFunction(13) = thdot1_f;
% endpointFunction(14) = thdot2_f;

%------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%
%
% To better understand the differences between a function, an equation and
% constraints specified by functions, see Section 1.3, page 37 of Ross.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%