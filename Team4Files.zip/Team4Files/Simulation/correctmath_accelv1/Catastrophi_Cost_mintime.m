function [EndpointCost, RunningCost] = Catastrophi_Cost(primal)
% Cost file for Catastrophi

%-----------------------------------------
% Call preamble and load primal variables:
%-----------------------------------------

[th1, th2, cly1, cly2, cly3, th1dot, th2dot, ... % states
     acc1, acc2, t, ...                                                 % controls and time
     x_0, t0, ...                                                         % endpoints at t0
     x_f, tf, ...                                                          % endpoints at tf
     m1, m2, eta, I1, I2, s1, s2, ...                             % constants
     DU] ...                                                               % scaling factors
                    = Catastrophi_Preamble(primal); 

% N = length(th1);
% x = [th1; th2; cly1; cly2; cly3; thdot1; thdot2] ;
% xf = [th1_f; th2_f; cly1_f; cly2_f; cly3_f; thdot1_f; thdot2_f];

u = [acc1; acc2]*DU.accz ;

% 
% diff = sum((x(1:5,:)-xf(1:5)).^2,2) ; 
% %Jf = sum(diff) + norm(x(:,end) - xf) ; 
% 
% %diff = sum((x-xf).^2,2) ; 
% 
% Jf = norm(x(:,end) - xf) ; 
Ju = trace(u*u') ;             
            
EndpointCost    = tf*DU.tz ;%Jf ;%*10;
RunningCost     = Ju/10000 ;%sum(diff)  ;

% That's it! Now, wasn't that easy? Hmm? Hmmm??
% Remember to fill the first output first!