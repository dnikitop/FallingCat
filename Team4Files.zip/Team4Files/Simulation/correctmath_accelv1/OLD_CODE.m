%
format compact; close all; clear; clc; 

%Making twist direction z
%Joint variables and rotation matrices for the universal joint
global x0 xf N dt I1 I2 T s1 s2 eta u_max n

n = 10; % 10 or 22
theta1 = 0 ;
theta2 = 0 ;
T = 0.75 ;
N = 10 ;
dt = T/N ;
% Initial conditions for link 1
% xrot = 0; %radians
% yrot = pi/6; %radians
% zrot = 0; %radians;
% Rx = [1 0 0; 0 cos(xrot) -sin(xrot); 0 sin(xrot) cos(xrot)]; %x-rot
% Ry = [cos(yrot) 0 sin(yrot); 0 1 0; -sin(yrot) 0 cos(yrot)]; % y-rot
% Rz = [cos(zrot) -sin(zrot) 0; sin(zrot) cos(zrot) 0; 0 0 1]; %z-rot
% Rinit = [cos(xrot)*cos(yrot)*cos(zrot)-sin(xrot)*sin(zrot) -cos(xrot)*cos(yrot)*sin(zrot)-sin(xrot)*cos(zrot) cos(xrot)*sin(yrot);...
%          sin(xrot)*cos(yrot)*cos(zrot)+cos(xrot)*sin(zrot) -sin(xrot)*cos(yrot)*sin(zrot)+cos(xrot)*cos(zrot) sin(xrot)*sin(yrot);...
%          -sin(yrot)*cos(zrot) sin(yrot)*sin(zrot) cos(yrot)];
% Rinit = [cos(-yrot) 0 sin(-yrot); 0 1 0; -sin(-yrot) 0 cos(-yrot)];
% Qinit = (eye(3)-Rinit)*inv(eye(3)+Rinit);
% cly123init = [Qinit(3,2) Qinit(1,3) Qinit(2,3)];
% cly0init = 1/(1+cly123init*cly123init');
% 
% Rfinal = Ry;
% Qfinal = (eye(3)-Rfinal)*inv(eye(3)+Rfinal);
% cly123final = [Qfinal(3,2) Qfinal(1,3) Qfinal(2,3)];
% cly0final = 1/(1+cly123final*cly123final');

%% Inertia properties
R2 = [0 0 1;
        0 1 0;
      -1 0 0]; 
  
R2_ = [0 0 -1;
          0 1 0;
          1 0 0];

 % Model from paper
    m1 = 1;
    m2 = 1;
    I1 = .01*[1 0 0; 0 1 0; 0 0 1];
    I2 = .01*[1 0 0; 0 1 0; 0 0 1];
    s1 = [0 0 -1]; 
    s2 = [0 0 -1];
   
 % Old Position
%     m1 = .31513; 
%     x1 = .11859 ;
%     y1 = .00320 ;
%     z1 = .00057 ;
%     I1 = R2*[0.00027 0.00051 -0.00001;
%                  0.00051 0.00196 0;
%                -0.00001 0 0.00213]*R2' ;
%     m2 = .37173; 
%     x2 = -.12647 ; 
%     y2 = .01317 ; 
%     z2 = .00799 ; 
%     I2 = R2*[0.00023 -0.00024 0.00032;
%                -0.00024 0.00219 -0.00004;
%                 0.00032 -0.00004 0.00215]*R2' ;

  % Frame attached close to motor
%     m1 = .31513; 
%     x1 = .06120 ; 
%     y1 = -.03041 ; 
%     z1 = -.02495 ; 
%     I1 = R2*[0.00027 0.00022 0; 
%                  0.00022 0.00059 0; 
%                 0 0 0.00076]*R2'; 
%     m2 = .31504; 
%     x2 = -.06068 ; 
%     y2 = .01199 ; 
%     z2 = .00946 ; 
%     I2 = R2*[0.00020 -0.00009 0.00013; 
%                -0.00009 0.00065 -0.00003; 
%                 0.00013 -0.00003 0.00062]*R2'; 

%     s1 = (R2*[x1 y1 z1]')' ;
%     s2 = (R2_*[x2 y2 z2]')' ;
    
eta = m1*m2/(m1+m2);

%% FMINCON

A = [] ;%empty because no linear equations
b = [] ;%empty because no linear equations
Aeq = [] ;%empty because no linear equations
beq = [] ;%empty because no linear equations

options =optimoptions(@fmincon,'TolFun',1E-10,'MaxIter',10000,...
    'MaxFunEvals',100000,'Display','iter','DiffMinChange',0.001);%,'Algorithm','sqp');

cly_max = inf ;%[unitless] 
paramAl_max = inf ; 
theta_max = 180*pi/180 ;%[rad] [90 deg] 
u_max = inf ;%120*pi/30 ;%[rad/s] [100 rpm] 

paramAl = 0*ones(1,10) ;

% x0 = [0 -1.14159 cly123init]';
% xf = [0 -1.14159 cly123final]';

x0 = [-1.14159 0 -0.999997 1.83048 0.546302]' ;
xf = [-1.14159 0 -1 -0.546305 -1.83049]' ;

% x0 = [-1.14159 0 -3 1.83048 0.546302]';
% xf = [-1.14159 0 -3 -0.546305 -1.83049]';

UB = [theta_max*ones(2,N);
        cly_max*ones(3,N);
        paramAl_max*ones(n,N)]; %paramAl_max*ones(10,N)];
LB = -UB;

params0 = [x0 zeros(size(x0,1),N-2) xf;
                  zeros(n,N)]; 

tic
COSTFUN = @(params) cost_to_minimize(params);
CONSTRAINTFUN = @(params) nonlinconstraints(params);
params = fmincon(COSTFUN,params0,A,b,Aeq,beq,LB,UB,CONSTRAINTFUN,options);
toc

    x = params(1:5,:);
    u = params(6:end,:);
             
    save x.mat;
    save u.mat;
    animateCat(x);
%    save theta_dot_final0.mat;
    %}
    global Alpha
    Alpha = u(:,1);
    
    theta_dot = [];
    Tau = [];
    for t = linspace(0,T,N)
        
        theta_dot = [theta_dot u_alpha(t, Alpha)];
       
    end
                  
%% PLOT

Time = linspace(0,T,size(x,2));
% figure
% plot(t,x)
figure, hold on;
subplot(221); plot(Time,theta_dot(1,:)*30/pi); xlim([0,T]); 
ylabel('Theta 1 Rate (RPM)','fontsize',16)

subplot(222); plot(Time,theta_dot(2,:)*30/pi); xlim([0,T]); 
ylabel('Theta 2 Rate (RPM)','fontsize',16)

subplot(223); plot(Time,x(1,:)); xlim([0,T]); 
xlabel('Time [s]','fontsize',16); ylabel('Theta 1 Angle (rad)','fontsize',16)

subplot(224); plot(Time,x(2,:)); xlim([0,T]); 
xlabel('Time [s]','fontsize',16); ylabel('Theta 2 Angle (rad)','fontsize',16)

% figure, plot(Time,u);
%}
%% ODE45 PROPAGATION

NN = 500;
tN = linspace(0,T,NN);

%[tN xN] = ode45(@Dynamics,[0 T],x0,args({Alpha}));
[tN xN] = ode45(@ODE_Dynamics,[0 T],x0);

% ODE45 Calculation of Velocity
tN_ = tN'*2*pi/T ;
e1_ = 0.5*ones(size(tN_)) ;%*
e2_ = sin(tN_) ;%*
e3_ = cos(tN_) ;%*
e4_ = sin(2*tN_) ;%*
e5_ = cos(2*tN_) ;%*
z_ = zeros(size(tN_)) ;%*

theta_dotN = [e1_;z_]*Alpha(1) + [z_;e1_]*Alpha(6) +...
                    [e2_;z_]*Alpha(2) + [z_;e2_]*Alpha(7) +...
                    [e3_;z_]*Alpha(3) + [z_;e3_]*Alpha(8) +...
                    [e4_;z_]*Alpha(4) + [z_;e4_]*Alpha(9) +...
                    [e5_;z_]*Alpha(5) + [z_;e5_]*Alpha(10);%
if n == 22
    e6_ = sin(3*tN_) ;%*
    e7_ = cos(3*tN_) ;%*
    e8_ = sin(4*tN_) ;%*
    e9_ = cos(4*tN_) ;%*
    e10_ = sin(5*tN_) ;%*
    e11_ = cos(5*tN_) ;%*
    theta_dotN = theta_dotN +...
        [e6_;z_]*Alpha(11) + [z_;e6_]*Alpha(17) +...
        [e7_;z_]*Alpha(12) + [z_;e7_]*Alpha(18) +...
        [e8_;z_]*Alpha(13) + [z_;e8_]*Alpha(19) +...
        [e9_;z_]*Alpha(14) + [z_;e9_]*Alpha(20) +...
        [e10_;z_]*Alpha(15) + [z_;e10_]*Alpha(21) +...
        [e11_;z_]*Alpha(16) + [z_;e11_]*Alpha(22) ;%
end

% TORQUE
mod = 1; 
clear tauN
for i = 1:length(tN)-1
    accel = (theta_dotN(:,i+1)-theta_dotN(:,i)) / (tN(i+1)-tN(i)) ;
    tauN(i,:) = ([I1(1,1)+I2(1,1) 0;0 I1(2,2)+I2(2,2)]*accel)' ;
end
                           
% ODE45 PLOTS                

% Plot Torque Velocity Angle
figure, hold on;
subplot(321); plot(tN(1:end-1),tauN(:,1)); xlim([0,T]); 
ylabel('Torque (N-m)','fontsize',16)

subplot(322); plot(tN(1:end-1),tauN(:,2)); xlim([0,T]); 
ylabel('Torque (N-m)','fontsize',16)

subplot(323); plot(tN,theta_dotN(1,:)*30/pi); xlim([0,T]); 
ylabel('Rate (RPM)','fontsize',16)

subplot(324); plot(tN,theta_dotN(2,:)*30/pi); xlim([0,T]); 
ylabel('Rate (RPM)','fontsize',16)

subplot(325); plot(tN,xN(:,1)*180/pi); xlim([0,T]); 
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)

subplot(326); plot(tN,xN(:,2)*180/pi); xlim([0,T]); 
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)

% Plot Caley Parameters
figure, hold on
subplot(221); plot(tN,xN(:,3)); xlim([0,T]); 
ylabel('c1','fontsize',16)

subplot(222); plot(tN,xN(:,4)); xlim([0,T]); 
ylabel('c2','fontsize',16)

subplot(223); plot(tN,xN(:,5)); xlim([0,T]); 
xlabel('Time [s]','fontsize',16); ylabel('c3','fontsize',16)

save xN.mat

%% NONLINEAR CONSTRAINTS
function [c,ceq] = nonlinconstraints(params) 
    global N x0 xf dt u_max
    
% FOR DIRECT COLLOCATION 
    x = params(1:5,:) ;
    u = params(6:end,:) ;
    t = 0 ;
    
    ceq_0 = x(:,1) - x0 ;
%    ceq_0 = [ceq_0; u_alpha(t, u)] ;
    ceq_f = x(:,end) - xf ; 
    ceq = ceq_0 ; 

    x_dot_k = Dynamics(t, x(:,1),u(:,1)) ; 
    
%    c = abs(u_alpha(t, u))-u_max ;%inequality <= constraint    
    
    for k = 1:N-1
        t = t + dt ;
        x_k = (x(:,k)) ;
        x_k_p1 = x(:,k+1) ;
        x_dot_k_p1 = Dynamics(t, x(:,k+1),u(:,k+1)) ;

        h = dt ;
        x_ck = 1/2*(x_k + x_k_p1) + h/8*(x_dot_k - x_dot_k_p1) ;
        u_ck = (u(:,k) + u(:,k+1))/2 ;
        x_dot_ck = Dynamics(t-dt/2, x_ck,u_ck) ;

        defects = (x_k - x_k_p1) + dt/6* (x_dot_k + 4*x_dot_ck + x_dot_k_p1) ;
        def_u = u(:,k) - u(:,k+1) ; 
 %       c = [c; abs(u_alpha(t, u))-u_max] ;%inequality <= constraint  

        ceq = [ceq;defects;def_u] ; 
        x_dot_k = x_dot_k_p1 ; 
    end
    c = [];
    ceq = [ceq;ceq_f] ;%equality = constraint  
    
end

%% COST FUNCTION
function J = cost_to_minimize(params)
    global xf
    x = params(1:5,:) ; 
    u = params(6:end,:) ; 
    
     Ju = trace(u*u') ;
     Jf = norm(x(:,end) - xf) ;
     lambda = 1 ;
     J = Ju + lambda*Jf; 
%    J = trace(x(1:2,:)*x(1:2,:)') + lambda*Jf;

end %cost_to_minimize function

%% FUNCTION DYNAMICS
function xdot = Dynamics(t, x, u)

    B = B_calc(x);
    
    Alpha = u;
    theta_dot = u_alpha(t, Alpha);%*

    xdot = B*theta_dot;%*
    
    %Omega skew-symm matrix
    
%     omega_skew = [   (((2*cdot + 2*a(t)*bdot + 2*b(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*c(t) + 2*a(t)*b(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(c(t)) + 2*conj(a(t))*conj(b(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*a(t)*cdot - 2*bdot + 2*c(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*b(t) - 2*a(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(b(t)) - 2*conj(a(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*b(t)*bdot - 2*a(t)*adot + 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 - b(t)^2 - c(t)^2 + 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 - conj(b(t))^2 - conj(c(t))^2 + 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1), (((2*a(t)*bdot - 2*cdot + 2*b(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*c(t) - 2*a(t)*b(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 - conj(b(t))^2 - conj(c(t))^2 + 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*adot + 2*b(t)*cdot + 2*c(t)*bdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t) + 2*b(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(b(t)) - 2*conj(a(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*a(t)*adot - 2*b(t)*bdot + 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 - b(t)^2 + c(t)^2 - 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(c(t)) + 2*conj(a(t))*conj(b(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1),   (((2*a(t)*adot + 2*b(t)*bdot - 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 + b(t)^2 - c(t)^2 - 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(b(t)) - 2*conj(a(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) + (((2*b(t)*cdot - 2*adot + 2*c(t)*bdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*a(t) - 2*b(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(c(t)) + 2*conj(a(t))*conj(b(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) + (((2*bdot + 2*a(t)*cdot + 2*c(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*b(t) + 2*a(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 - conj(b(t))^2 - conj(c(t))^2 + 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1);...
%        (((2*b(t)*bdot - 2*a(t)*adot + 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 - b(t)^2 - c(t)^2 + 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(c(t)) - 2*conj(a(t))*conj(b(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*cdot + 2*a(t)*bdot + 2*b(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*c(t) + 2*a(t)*b(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 - conj(b(t))^2 + conj(c(t))^2 - 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) + (((2*a(t)*cdot - 2*bdot + 2*c(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*b(t) - 2*a(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(a(t)) + 2*conj(b(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1), (((2*adot + 2*b(t)*cdot + 2*c(t)*bdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t) + 2*b(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(a(t)) + 2*conj(b(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*a(t)*bdot - 2*cdot + 2*b(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*c(t) - 2*a(t)*b(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(c(t)) - 2*conj(a(t))*conj(b(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) + (((2*a(t)*adot - 2*b(t)*bdot + 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 - b(t)^2 + c(t)^2 - 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 - conj(b(t))^2 + conj(c(t))^2 - 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1), - (((2*a(t)*adot + 2*b(t)*bdot - 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 + b(t)^2 - c(t)^2 - 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(a(t)) + 2*conj(b(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*b(t)*cdot - 2*adot + 2*c(t)*bdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*a(t) - 2*b(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 - conj(b(t))^2 + conj(c(t))^2 - 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*bdot + 2*a(t)*cdot + 2*c(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*b(t) + 2*a(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(c(t)) - 2*conj(a(t))*conj(b(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1);...
%      - (((2*a(t)*cdot - 2*bdot + 2*c(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*b(t) - 2*a(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 + conj(b(t))^2 - conj(c(t))^2 - 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*b(t)*bdot - 2*a(t)*adot + 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 - b(t)^2 - c(t)^2 + 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(b(t)) + 2*conj(a(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*cdot + 2*a(t)*bdot + 2*b(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*c(t) + 2*a(t)*b(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(a(t)) - 2*conj(b(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1), (((2*a(t)*adot - 2*b(t)*bdot + 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 - b(t)^2 + c(t)^2 - 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(a(t)) - 2*conj(b(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*adot + 2*b(t)*cdot + 2*c(t)*bdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t) + 2*b(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 + conj(b(t))^2 - conj(c(t))^2 - 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) + (((2*a(t)*bdot - 2*cdot + 2*b(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*c(t) - 2*a(t)*b(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(b(t)) + 2*conj(a(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1),   (((2*bdot + 2*a(t)*cdot + 2*c(t)*adot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*b(t) + 2*a(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(b(t)) + 2*conj(a(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) - (((2*b(t)*cdot - 2*adot + 2*c(t)*bdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) + ((2*a(t) - 2*b(t)*c(t))*(2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(2*conj(a(t)) - 2*conj(b(t))*conj(c(t))))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1) + (((2*a(t)*adot + 2*b(t)*bdot - 2*c(t)*cdot)/(a(t)^2 + b(t)^2 + c(t)^2 + 1) - ((2*a(t)*adot + 2*b(t)*bdot + 2*c(t)*cdot)*(a(t)^2 + b(t)^2 - c(t)^2 - 1))/(a(t)^2 + b(t)^2 + c(t)^2 + 1)^2)*(conj(a(t))^2 + conj(b(t))^2 - conj(c(t))^2 - 1))/(conj(a(t))^2 + conj(b(t))^2 + conj(c(t))^2 + 1)];
%     
    omega_skew = [   (((2*xdot(5) + 2*x(3)*xdot(4) + 2*x(4)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(5) + 2*x(3)*x(4))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(5)) + 2*conj(x(3))*conj(x(4))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(3)*xdot(5) - 2*xdot(4) + 2*x(5)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(4) - 2*x(3)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(4)) - 2*conj(x(3))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(4)*xdot(4) - 2*x(3)*xdot(3) + 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 - x(4)^2 - x(5)^2 + 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 - conj(x(4))^2 - conj(x(5))^2 + 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1), (((2*x(3)*xdot(4) - 2*xdot(5) + 2*x(4)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(5) - 2*x(3)*x(4))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 - conj(x(4))^2 - conj(x(5))^2 + 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*xdot(3) + 2*x(4)*xdot(5) + 2*x(5)*xdot(4))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3) + 2*x(4)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(4)) - 2*conj(x(3))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(3)*xdot(3) - 2*x(4)*xdot(4) + 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 - x(4)^2 + x(5)^2 - 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(5)) + 2*conj(x(3))*conj(x(4))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1),   (((2*x(3)*xdot(3) + 2*x(4)*xdot(4) - 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 + x(4)^2 - x(5)^2 - 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(4)) - 2*conj(x(3))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) + (((2*x(4)*xdot(5) - 2*xdot(3) + 2*x(5)*xdot(4))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(3) - 2*x(4)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(5)) + 2*conj(x(3))*conj(x(4))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) + (((2*xdot(4) + 2*x(3)*xdot(5) + 2*x(5)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(4) + 2*x(3)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 - conj(x(4))^2 - conj(x(5))^2 + 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1);...
       (((2*x(4)*xdot(4) - 2*x(3)*xdot(3) + 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 - x(4)^2 - x(5)^2 + 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(5)) - 2*conj(x(3))*conj(x(4))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*xdot(5) + 2*x(3)*xdot(4) + 2*x(4)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(5) + 2*x(3)*x(4))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 - conj(x(4))^2 + conj(x(5))^2 - 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) + (((2*x(3)*xdot(5) - 2*xdot(4) + 2*x(5)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(4) - 2*x(3)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(3)) + 2*conj(x(4))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1), (((2*xdot(3) + 2*x(4)*xdot(5) + 2*x(5)*xdot(4))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3) + 2*x(4)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(3)) + 2*conj(x(4))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(3)*xdot(4) - 2*xdot(5) + 2*x(4)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(5) - 2*x(3)*x(4))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(5)) - 2*conj(x(3))*conj(x(4))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) + (((2*x(3)*xdot(3) - 2*x(4)*xdot(4) + 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 - x(4)^2 + x(5)^2 - 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 - conj(x(4))^2 + conj(x(5))^2 - 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1), - (((2*x(3)*xdot(3) + 2*x(4)*xdot(4) - 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 + x(4)^2 - x(5)^2 - 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(3)) + 2*conj(x(4))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(4)*xdot(5) - 2*xdot(3) + 2*x(5)*xdot(4))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(3) - 2*x(4)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 - conj(x(4))^2 + conj(x(5))^2 - 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*xdot(4) + 2*x(3)*xdot(5) + 2*x(5)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(4) + 2*x(3)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(5)) - 2*conj(x(3))*conj(x(4))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1);...
     - (((2*x(3)*xdot(5) - 2*xdot(4) + 2*x(5)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(4) - 2*x(3)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 + conj(x(4))^2 - conj(x(5))^2 - 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(4)*xdot(4) - 2*x(3)*xdot(3) + 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 - x(4)^2 - x(5)^2 + 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(4)) + 2*conj(x(3))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*xdot(5) + 2*x(3)*xdot(4) + 2*x(4)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(5) + 2*x(3)*x(4))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(3)) - 2*conj(x(4))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1), (((2*x(3)*xdot(3) - 2*x(4)*xdot(4) + 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 - x(4)^2 + x(5)^2 - 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(3)) - 2*conj(x(4))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*xdot(3) + 2*x(4)*xdot(5) + 2*x(5)*xdot(4))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3) + 2*x(4)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 + conj(x(4))^2 - conj(x(5))^2 - 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) + (((2*x(3)*xdot(4) - 2*xdot(5) + 2*x(4)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(5) - 2*x(3)*x(4))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(4)) + 2*conj(x(3))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1),   (((2*xdot(4) + 2*x(3)*xdot(5) + 2*x(5)*xdot(3))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(4) + 2*x(3)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(4)) + 2*conj(x(3))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) - (((2*x(4)*xdot(5) - 2*xdot(3) + 2*x(5)*xdot(4))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) + ((2*x(3) - 2*x(4)*x(5))*(2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5)))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(2*conj(x(3)) - 2*conj(x(4))*conj(x(5))))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1) + (((2*x(3)*xdot(3) + 2*x(4)*xdot(4) - 2*x(5)*xdot(5))/(x(3)^2 + x(4)^2 + x(5)^2 + 1) - ((2*x(3)*xdot(3) + 2*x(4)*xdot(4) + 2*x(5)*xdot(5))*(x(3)^2 + x(4)^2 - x(5)^2 - 1))/(x(3)^2 + x(4)^2 + x(5)^2 + 1)^2)*(conj(x(3))^2 + conj(x(4))^2 - conj(x(5))^2 - 1))/(conj(x(3))^2 + conj(x(4))^2 + conj(x(5))^2 + 1)];

    if norm(omega_skew + omega_skew') > 1.0000e-10
        flag = 1 ;
    end  
       
end

%% FUNCTION DYNAMICS FOR ODE45
function xdot = ODE_Dynamics(t,x)
    global Alpha
    
    B = B_calc(x);
    
    theta_dot = u_alpha(t, Alpha) ;%*

    xdot = B*theta_dot ;%*
end

function B = B_calc(x)

    global I1 I2 s1 s2 eta
    %Inertia matrices for the bodies in body frame

    theta1 = x(1) ;
    theta2 = x(2) ;

    skew_s1 = to_skewSymm(s1);
    skew_s2 = to_skewSymm(s2);
    
    %Rotation matrices for the bodies in inertial frame
%% Check A (eqn 14, page 388)
%       A = [cos(theta1) 0 sin(theta1); 0 1 0; -sin(theta1) 0 cos(theta1)]*[0 1 0;cos(theta2) 0 sin(theta2); sin(theta2) 0 -cos(theta2)];
    A = [cos(theta1) sin(theta1)*sin(theta2) sin(theta1)*cos(theta2);
            0 cos(theta2) -sin(theta2);
          -sin(theta1) cos(theta1)*sin(theta2) cos(theta1)*cos(theta2)];
%    A = [cos(theta1) 0 sin(theta1); 0 1 0; -sin(theta1) 0 cos(theta1)]*[1 0 0;0 cos(theta2) -sin(theta2); 0 sin(theta2) cos(theta2)]
    cly123 = x(3:5) ;%*
    cly0 = 1/(1 + cly123'*cly123) ;%*

%     alpha0 = 1/(1+Q(1,2)^2+Q(1,3)^2+Q(2,3)^2);
    alpha1 = cly123(1);%*
    alpha2 = cly123(2);%*
    alpha3 = cly123(3);%*
%     alpha = [alpha0 alpha1 alpha2 alpha3];

%% Changed calculation of A1 per pg 386
    A1_ = cly0*...
            [1 + alpha1^2 - alpha2^2 - alpha3^2,...
             2*(alpha1*alpha2 - alpha3),...
             2*(alpha1*alpha3 + alpha2);
             2*(alpha1*alpha2 + alpha3),...
             1 - alpha1^2 + alpha2^2 - alpha3^2,...
             2*(alpha2*alpha3 - alpha1);
             2*(alpha1*alpha3 - alpha2),...
             2*(alpha2*alpha3 + alpha1),...
             1 - alpha1^2 - alpha2^2 + alpha3^2] ;%*
%%
    Q = to_skewSymm(cly123);
%     Q = (eye(3)-A1)*inv(eye(3)+A1);
    A1 = (eye(3)+Q)*inv(eye(3)-Q) ;%Cayley to rotation matrix conversion 
    %A1 = inv(eye(3)+Q)*(eye(3)-Q) ;%Cayley to rotation matrix conversion        %%%%%%%%%%%%%%%%%%%%%%%%

    A_diff = norm(A1-A1_) % check difference between A1 calculations (VERY DIFFERENT!!)
    A2 = A1*A ;%*
         
    %Generalized matrix
    J1 = I1 + eta*(skew_s1'*skew_s1);%*
    J2 = I2 + eta*(skew_s2'*skew_s2);%*
    J12 = eta*(skew_s1*A*skew_s2);%*

    J = [J1 J12; J12' J2];%*

%% NOT SURE HOW U IS CALCULATED
    U = [((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1), (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        ((2*conj(alpha1) - 2*conj(alpha2)*conj(alpha3))*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(alpha1^2 - alpha2^2 + alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha1 + 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 + conj(alpha2)^2 - conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 - 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha2) + 2*conj(alpha1)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1);...
        ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1), (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha1 - 2*alpha2*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) + 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2*conj(alpha2) - 2*conj(alpha1)*conj(alpha3))*((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 + alpha2^2 - alpha3^2 - 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha2 + 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 - conj(alpha3)^2 + 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1);...
        (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha1*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha1*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        (((2*alpha2)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha2*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha2*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1),        (((2*alpha1)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(2*alpha2 - 2*alpha1*alpha3))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha1) + 2*conj(alpha2)*conj(alpha3)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) - ((2/(alpha1^2 + alpha2^2 + alpha3^2 + 1) - (2*alpha3*(2*alpha3 + 2*alpha1*alpha2))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(conj(alpha1)^2 - conj(alpha2)^2 + conj(alpha3)^2 - 1))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1) + (((2*alpha3)/(alpha1^2 + alpha2^2 + alpha3^2 + 1) + (2*alpha3*(alpha1^2 - alpha2^2 - alpha3^2 + 1))/(alpha1^2 + alpha2^2 + alpha3^2 + 1)^2)*(2*conj(alpha3) - 2*conj(alpha1)*conj(alpha2)))/(conj(alpha1)^2 + conj(alpha2)^2 + conj(alpha3)^2 + 1)];

    %%    
    Il = J1 + A*J2*A' + A*J12' + J12*A';%*
    b2 = [0;1;0];%*
    b1 = [cos(theta2); 0; sin(theta2)];%*
    B1 = [1 0 zeros(1,3); 
             0 1 zeros(1,3); 
             zeros(3,2) Il*U];%*
    B2 = [1 0; 
             0 1; 
             -(A*J2+J12)*b1 -(A*J2 + J12)*b2];%*
    B = inv(B1)*B2;%*

end

%% FUNCTION Control Calc
function theta_dot = u_alpha(t, Alpha)
    global T n
    u = Alpha; 
    t_ = t*2*pi/T; 

    e1_ = 0.5 ;%*
    e2_ = sin(t_) ;%*
    e3_ = cos(t_) ;%*
    e4_ = sin(2*t_) ;%*
    e5_ = cos(2*t_) ;%*
    z_ = 0 ;%*
    
    theta_dot = [e1_;z_]*u(1) + [z_;e1_]*u(6) +...
                      [e2_;z_]*u(2) + [z_;e2_]*u(7) +...
                      [e3_;z_]*u(3) + [z_;e3_]*u(8) +...
                      [e4_;z_]*u(4) + [z_;e4_]*u(9) +...
                      [e5_;z_]*u(5) + [z_;e5_]*u(10);%*
    if n == 22
        e6_ = sin(3*t_) ;%*
        e7_ = cos(3*t_) ;%*
        e8_ = sin(4*t_) ;%*
        e9_ = cos(4*t_) ;%*
        e10_ = sin(5*t_) ;%*
        e11_ = cos(5*t_) ;%*
        theta_dot = theta_dot +...
                      [e6_;z_]*u(11) + [z_;e6_]*u(17) +...
                      [e7_;z_]*u(12) + [z_;e7_]*u(18) +...
                      [e8_;z_]*u(13) + [z_;e8_]*u(19) +...
                      [e9_;z_]*u(14) + [z_;e9_]*u(20) +...
                      [e10_;z_]*u(15) + [z_;e10_]*u(21) +...
                      [e11_;z_]*u(16) + [z_;e11_]*u(22);%
    end

end

%% FUNCTION SKEW SYMMETRIC MATRIX
function skewSymmMat = to_skewSymm(vec)
    skewSymmMat = [0 -vec(3) vec(2); 
                               vec(3) 0 -vec(1); 
                              -vec(2) vec(1) 0];%*
end

%
function animateCat(x)
    % z is axis of cat body
    %Inertial frame attached to center of mass of body 1 at r1(0,0,0)
    
    link = [1 1];
    leg = 0.4;
    figure;

    for i = 1:size(x,2)
        cly123 = x(3:5, i); 
        th      = x(1:2, i);  
        Q = to_skewSymm(cly123);
        
        % Defining rotation matrices
        R = (eye(3)+Q)*inv(eye(3)-Q);
        % Basic rotation matrices
        R1 = [1 0 0; 0 cos(th(1)) -sin(th(1)); 0 sin(th(1)) cos(th(1))]; %x-rot
        R2 = [cos(th(2)) 0 sin(th(2)); 0 1 0; -sin(th(2)) 0 cos(th(2))]; % y-rot
        R3 = [cos(th(1)) -sin(th(1)) 0; sin(th(1)) cos(th(1)) 0; 0 0 1]; %z-rot
        % From dynamics equations
        R3_ = [cos(th(1)) sin(th(1))*sin(th(2)) sin(th(1))*cos(th(2));
                0 cos(th(2)) -sin(th(2));
                -sin(th(1)) cos(th(1))*sin(th(2)) cos(th(1))*cos(th(2))];
    
        l1 = link(1)/2;

        r1 = [0 0 0];
        T1 = [eye(3) [0 0 l1]'; [0 0 0 1]];
        A1 = [R [0 0 0]'; [0 0 0 1]];
        Tleg1 = [eye(3) [-leg 0 -l1]'; [0 0 0 1]];

        r2 = A1*T1*[0 0 0 1]'; % End of link 1, start of link 2

        T0 = [eye(3) [0 0 -l1]'; [0 0 0 1]];
        r0 = A1*T0*[0 0 0 1]'; %Start of link 1
        

        A3 = [R2 [0 0 0]'; [0 0 0 1]];
        A3_ = [R3_ [0 0 0]'; [0 0 0 1]];
        A33 = [R3 [0 0 0]'; [0 0 0 1]];
        
        T3 = [eye(3) [0 0 link(2)]'; [0 0 0 1]];
        T33 = [eye(3) [0 0 link(2)/2]'; [0 0 0 1]];
%         r3 = A1*T1*A3*A33*T3*[0 0 0 1]'; %End of link 2
        r3 = A1*T1*A3_*T3*[0 0 0 1]'; %End of link 2
        
        r4 = A1*T1*A3*A33*T33*[0 0 0 1]';
        Tleg2 = [eye(3) [-leg 0 link(2)]'; [0 0 0 1]];
        leg1 = A1*Tleg1*[0 0 0 1]';
%         leg2 = A1*T1*A3*A33*Tleg2*[0 0 0 1]';
        leg2 = A1*T1*A3_*Tleg2*[0 0 0 1]';
        
        clf;
        R = 0.2;
        N = 30;
        [X,Y,Z]=cylinder2P(R,N,r0(1:3)',r2(1:3)'); % Link 1
        surf(X,Y,Z);
        hold on;
        [X2,Y2,Z2]=cylinder2P(R,N,r2(1:3)',r3(1:3)'); % Link2
        surf(X2,Y2,Z2);
        R = 0.1;
        [X3,Y3,Z3]=cylinder2P(R,N,r0(1:3)',leg1(1:3)'); % Leg1
        surf(X3,Y3,Z3);
        [X4,Y4,Z4]=cylinder2P(R,N,r3(1:3)',leg2(1:3)'); %Leg2
        surf(X4,Y4,Z4);
        
        axis([-2 3 -1.4 2 -1.4 2]);
        title('Cat reorientation')
        xlabel('x') % x-axis label
        ylabel('y') % y-axis label
        zlabel('z') % y-axis label
        Mov(i) = getframe;
        pause(0.5);
    end
    save('movie','Mov');
    %     load('movie.mat')
    %     movie(Mov,2) % To play it two times

end
%}