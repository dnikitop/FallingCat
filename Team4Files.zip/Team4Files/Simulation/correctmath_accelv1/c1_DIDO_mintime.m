%==========================================================================
% The main purpose of this file is to populate the computational line:
% 
% [cost, primal, dual] = dido(Brac1, algorithm)
%
%==========================================================================


%---------
% Step 1:       % Always a good idea to begin with this!
clear all; close all; clc; % Ignore MATLAB's suggestion to not do this!
%---------
% global bounds 

refine = 2 ;% 0 (no guess, low nodes) 1 (refine guess with more nodes)
%-------------------%
% DEFINE THE PROBLEM
%   - Do NOT code unless you have written down the problem
%   - Ref: The DIDO Tutorial and Page 12 of Ross
%-------------------%


% open this and the end section (before plots) to run a large loop
%{
thdot_iter = [55 60 65 70 72.5 75 77.5 80 85 90 95 100 105 110]*pi/30 ;%[rad/s] [shown in rpm]
for iter = 1:length(thdot_iter)
    thdot_max = thdot_iter(iter);
%}
    
%--------
% Step 6:      % Set up problem-specific constants
%--------

% R3 = [0 -1 0;
%          1 0 0;
%          0 0 1];
% R2 = [0 0 -1;
%         0 1 0;
%         1 0 0]; 
% R = R3*R2; %rotation to get CAD aligned with paper coordinates
% FIXED =  [0 1 0;
%                1 0 0;
%                0 0 -1]; % fixed rotation within A (from paper)
% m1 = 0.2558; 
% x1 = .065444 ; 
% y1 = 0.003148 ;  
% z1 = -0.000221 ; 
% I1 = R*[0.223309 0.195005 0.053015; 
%            0.195005 0.694704 0.036684; 
%            0.053015 0.036684 0.807171]/1000*R'; 
% m2 = 0.2340; 
% x2 = -.070804 ; 
% y2 = -0.001443 ;  
% z2 = -0.000305 ; 
% I2 = (FIXED*R)*[0.195008 0.027496 0.204416; 
%            0.027496 0.815644 0.009076; 
%            0.204416 0.009076 0.689093]/1000*(FIXED*R)'; 
% s1 = (R*[x1 y1 z1]')' ;
% s2 = ((FIXED*R)*[x2 y2 z2]')' ;

R3 = [0 -1 0;
         1 0 0;
         0 0 1];
R2 = [0 0 -1;
        0 1 0;
        1 0 0]; 
R = R3*R2; %rotation to get CAD aligned with paper coordinates
FIXED =  [0 1 0;
               1 0 0;
               0 0 -1]; % fixed rotation within A (from paper)
m1 = 0.2558; 
x1 = .065444 ; 
y1 = 0 ;  
z1 = 0; 

m2 = m1 ; 
x2 = -x1; 
y2 = y1 ;  
z2 = z1 ;
I2 = (FIXED*R)*[0.195008 0 0; 
                       0 0.815644 0; 
                       0 0 0.689093]/1000*(FIXED*R)';     
I1 = I2 ;
s1 = (R*[x1 y1 z1]')' 
s2 = ((FIXED*R)*[x2 y2 z2]')' 

T = 0.75 ;

% m1 = .33 ;
% m2 = m1 ;
% I1 = .001*eye(3).*[2 2 .2] ;
% I2 = I1 ;
% s1 = .12*[0 0 1] ; 
% s2 = .12*[0 0 1] ;
 
eta = m1*m2/(m1+m2);

CON.m1 = m1; 
CON.m2 = m2; 
CON.I1 = I1; 
CON.I2 = I2; 
CON.s1 = s1; 
CON.s2 = s2; 
CON.eta = eta; 

Catastrophi.constants.CON = CON;    % The DIDO field name is "constants"

%--------
% Step 2:       % Provide a search space for DIDO
%--------

th_max = 90*pi/180 ;%[rad] max angle [90 deg]
cly_max = 10 ;
thdot_max = 95*pi/30 ;%[rad/s] max rate [95 rpm]
acc_max = 1000 ;
tau_max = 1.8 ;
w_max = 1000 ;

%--------
% Designer Units / scaling factors

DU.wz = 1 ;
DU.tauz = 1 ;

%{
% DU.thz = th_max ;%/10 ;
% DU.tz = 1*10;
% DU.thdotz = DU.thz/DU.tz ;
% DU.clyz = cly_max ;%/10 ;
% DU.accz = DU.thdotz/DU.tz ;
% % INFEASIBLE

% DU.thz = th_max/1 ;
% DU.tz = 1;
% DU.thdotz = thdot_max/1 ;
% DU.clyz = cly_max/1 ;
% DU.accz = acc_max/1 ;
% % 273 / 79

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/1 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/10 ;
% % 221 / 61

% DU.thz = th_max/10 ;
% DU.tz = 1;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max/10 ;
% DU.accz = acc_max/10 ;
% % 199 / 62

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max/1 ;
% DU.accz = acc_max/10 ;
% % 183 / 55

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*20 ;
% DU.accz = acc_max/10 ;
% % 178 / 51

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max/10 ;
% DU.accz = acc_max/10 ;
% % 171 / 49

% DU.thz = th_max/10 ;
% DU.tz = 1/1;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/10 ;
% % 169 / 61

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*5 ;
% DU.accz = acc_max/10 ;
% % 141 / 41

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/100 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/10 ;
% % 133 / 41

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/10 ;
% % 122 / 35 // 239 / 71

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/10 ;
% % 121 / 35 // 237 / 71

% DU.thz = th_max/10 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/5 ;
% % 96 / 25 // 240 / 73

% DU.thz = th_max/5 ;
% DU.tz = 1/10;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/5 ;
% % 123 / 36 // 206 / 62

% DU.thz = th_max/10 ;
% DU.tz = 1/5;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/5 ;
% % 100 / 32 // 221 / 67

% DU.thz = th_max/10 ;
% DU.tz = 1/5 ;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/5 ;

% DU.thz = 1;
% DU.tz = 1;
% DU.thdotz = 1;
% DU.clyz = 1;
% DU.accz = 10;
% % 149 / 42 // INFEASIBLE

% DU.thz = th_max;
% DU.tz = T;
% DU.thdotz = 10;
% DU.clyz = 1;
% DU.accz = 100;
% %  

% DU.thz = th_max/10 ;
% DU.tz = 1/5;
% DU.thdotz = thdot_max/10 ;
% DU.clyz = cly_max*10 ;
% DU.accz = acc_max/5 ;
% % 105 / 33 // DIDN"T SOLVE RIGHT

%}

DU.thz = 1;
DU.tz = 1;
DU.thdotz = 1;
DU.clyz = 1;
DU.accz = 1;
% (20) 144 / 56 // (35) 266 / 81 // (60) 12934 / 9033

Catastrophi.constants.DU = DU ;

th_max = th_max/DU.thz ;
cly_max = cly_max/DU.clyz ;
thdot_max = thdot_max/DU.thdotz ;
acc_max = acc_max/DU.accz ;
w_max = w_max/DU.wz ;
tau_max = tau_max/DU.tauz ;
T = T/DU.tz ;

search.states     = [th_max*[1 1],...        % search space for theta
                            cly_max*[1 1 1],...     % search space for Caley Parameters
                            thdot_max*[1 1]]'...  % search space for thetadot
                            *[-1 1] ;

search.controls = acc_max*ones(2,1)... %search space for thddot
                          *[-1 1] ;
%--------
% Step 3:       % Supply the boundary conditions using event bounds
%--------

x0 = [-1.14159 0 -0.999997 1.83048 0.546302 0 0]' ;
xf = [-1.14159 0 -1 -0.546305 -1.83049 0 0]' ;

X_DU = [DU.thz*[1 1] DU.clyz*[1 1 1] DU.thdotz*[1 1]];

x0 = x0./X_DU';
xf = xf./X_DU';

bounds.events     = [x0; xf]*[1 1] ; 
                          
%--------
% Step 4:       % Set up the initial- and final-time conditions. 
%--------
                
bounds.initial.time     = [0, 0] ;% t0 = 0
bounds.final.time       = [0, T] ;% tf = 0.75 sec

%--------
% Step 5:       % Define the problem using DIDO expressions
%--------

Catastrophi.cost         = 'Catastrophi_Cost_mintime';           % Watch out for case-sensitive
Catastrophi.dynamics = 'Catastrophi_Dynamics';       % errors
Catastrophi.events     = 'Catastrophi_Events';
% Catastrophi.path       = 'Catastrophi_Path';
Catastrophi.bounds  = bounds;       
Catastrophi.search   = search;          

%--------
% Step 7:       % Check your problem formulation (using the DIDO Doctor
                % Toolkit)
%--------

check(Catastrophi);

% The following lines will not run if your problem fails the doctor's test!

%
%-------             
% Step 8:       % Setup the algorithm
%--------

algorithm.nodes = 20;       % 10 points is usually a very good idea to
                            % start up the algorithm. 

%--------
% Step 9:       % call dido
%--------
tic
startTime = cputime ;% start the clock 
[cost, primal, dual] = dido(Catastrophi, algorithm);
NoGuessRunTime = cputime - startTime
toc

if refine > 0
    algorithm.nodes = 35;       
    algorithm.guess = primal;

    tic
    startTime = cputime ;% start the clock 
    [cost, primal, dual] = dido(Catastrophi, algorithm);
    GuessRunTime = cputime - startTime
    toc

    if refine > 1
        algorithm.nodes = 60;       
        algorithm.guess = primal;

        tic
        startTime = cputime ;% start the clock 
        [cost, primal, dual] = dido(Catastrophi, algorithm);
        GuessRunTime = cputime - startTime
        toc
    end

end
%%%%%%%%%%%%%%%%%%%%%%
%  Process Output    %
%%%%%%%%%%%%%%%%%%%%%%

[th1, th2, cly1, cly2, cly3, th1dot, th2dot, ... % states
     acc1, acc2, t, ...                                                 % controls and time
     x_0, t0, ...                                                         % endpoints at t0
     x_f, tf, ...                                                          % endpoints at tf
     m1, m2, eta, I1, I2, s1, s2, ...                             % constants
     DU] ...                                                               % scaling factors
                    = Catastrophi_Preamble(primal); 
          
figure, plot(t, primal.controls,'-g')
hold on, plot(t, dual.controls,'-r')
set(gcf,'Position',[50 350 400 300])

figure, plot(t, primal.states(6:7,:),'-g')
hold on, plot(t, dual.dynamics(6:7,:),'-r')
set(gcf,'Position',[50 1 400 300])

figure, plot(t, primal.states(1:2,:),'-g')
hold on, plot(t, dual.dynamics(1:2,:),'-r')
set(gcf,'Position',[450 350 400 300])

figure, plot(t, primal.states(3:5,:),'-g')
hold on, plot(t, dual.dynamics(3:5,:),'-r')
set(gcf,'Position',[450 1 400 300])

%---------
% Step 10:       % plot/process primal
%---------

acc1 = acc1*DU.accz ;
acc2 = acc2*DU.accz ;
th1 = th1*DU.thz ;
th2 = th2*DU.thz ;
th1dot = th1dot*DU.thdotz ;
th2dot = th2dot*DU.thdotz ;
cly1 = cly1*DU.clyz ;
cly2 = cly2*DU.clyz ;
cly3 = cly3*DU.clyz ;
t = t*DU.tz ;
tf = tf*DU.tz ;

fprintf('thdot max: %f rpm\n',thdot_max*30/pi)
acc1_max = max(abs(acc1)) ;%*(I1(1,1)+I2(1,1)) ;
acc2_max = max(abs(acc2)) ;%*(I1(2,2)+I2(2,2)) ;
fprintf('thddot1 max: %f N-m\n',acc1_max) 
fprintf('Accel (rad/s^2)2 max: %f N-m\n',acc2_max) 
thdot1_max = max(abs(th1dot))*30/pi ;
thdot2_max = max(abs(th2dot))*30/pi ;
fprintf('thdot1 max: %f rpm\n',thdot1_max) 
fprintf('thdot2 max: %f rpm\n',thdot2_max) 
th1_range = abs(max(th1)-min(th1))*180/pi ;
th2_range = abs(max(th1)-min(th1))*180/pi ;
fprintf('th1 range: %f deg\n',th1_range)
fprintf('th2 range: %f deg\n',th2_range)

%{
thdot_max_iter(iter) = max([thdot1_max thdot2_max]);
tau_max_iter(iter) = max([tau1_max tau2_max]);
th_range_iter(iter) = max([th1_range th2_range]);

end 

figure, hold on, title('Actuator RPM vs Torque for Falling Cat','fontsize',18)
subplot(211), scatter(thdot_max_iter(2:end),tau_max_iter(2:end))
ylabel('max torque [N-m]','fontsize',16)
subplot(212), scatter(thdot_max_iter(2:end),th_range_iter(2:end))
xlabel('Max Rate [rpm]','fontsize',16); ylabel('Max Angle Deflection [deg]','fontsize',16)

ax=axes('Units','Normal','Position',[.075 .075 .85 .85],'Visible','off');
set(get(ax,'Title'),'Visible','on')
title('Actuator RPM vs Torque for Falling Cat');
%}

%
% Plot Torque Velocity Angle
figure, hold on;
subplot(321); plot(t,acc1); xlim([0,tf]); 
ylabel('Accel (rad/s^2)','fontsize',16)
subplot(322); plot(t,acc2); xlim([0,tf]); 
ylabel('Accel (rad/s^2)','fontsize',16)
subplot(323); plot(t,th1dot*30/pi); xlim([0,tf]); 
ylabel('Rate (RPM)','fontsize',16)
subplot(324); plot(t,th2dot*30/pi); xlim([0,tf]); 
ylabel('Rate (RPM)','fontsize',16)
subplot(325); plot(t,th1*180/pi); xlim([0,tf]); 
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)
subplot(326); plot(t,th2*180/pi); xlim([0,tf]); 
xlabel('Time [s]','fontsize',16); ylabel('Angle (deg)','fontsize',16)

% Plot Caley Parameters
figure, hold on
subplot(221); plot(t,cly1); xlim([0,tf]); 
ylabel('c1','fontsize',16)
subplot(222); plot(t,cly2); xlim([0,tf]); 
ylabel('c2','fontsize',16)
subplot(223); plot(t,cly3); xlim([0,tf]); 
xlabel('Time [s]','fontsize',16); ylabel('c3','fontsize',16)

%---------
% Step 11:       % Plot/process duals
%---------
% Sample processing.  See Section 3.2 of Ross for complete details.
%---------
% lam_th1   = dual.dynamics(1,:);
% lam_th2   = dual.dynamics(2,:);
% lam_cly1   = dual.dynamics(3,:);
% lam_cly2   = dual.dynamics(4,:);
% lam_cly3   = dual.dynamics(5,:);
% lam_th1dot   = dual.dynamics(6,:);
% lam_th2dot   = dual.dynamics(7,:);
% 
% figure;
% plot(t, [lam_th1; lam_th2; lam_th1dot; lam_th2dot]);%; lam_cly1; lam_cly3; lam_cly3]);
% title('Dual Dynamics');
% legend('\lambda_{\theta_1}', '\lambda_{\theta_2}', '\lambda_{d\theta_1}', '\lambda_{d\theta_2}', '\lambda_{cly_1}', '\lambda_{cly_2}', '\lambda_{cly_3}');
% xlabel('t');    
         
save('LOAD_DIDO.mat')

c2_Propagate

%--------
% Step 12:       % Perform V&V.  This is crtically important.  You should
                 % not trust any solution coming out of any code, including
                 % DIDO, without performing V&V.  See Sec 3.2.1 of Ross for
                 % complete details.  The V&V shows that 10 nodes for the
                 % choice of algorithm was sufficiently accurate.
%--------
%}